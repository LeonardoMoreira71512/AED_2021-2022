package aed.sorting;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Random;

@SuppressWarnings("unused")
public class QuickSort3Way extends Sort {

	final static int LENGTH = 100000;
	final static int TESTES = 50;

	public static void main(String[] args) {
		var a = new Integer[31];
		for (int i = 0; i < 31; i++)
			a[i] = i;

		Integer[] b = { 0, 1, 0, 4, 8, 5, 9, 5, 2, 2, 2, 0, 6, 7 };
		Integer[] c = { 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 };
		Integer[] d = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };

		shuffle(a);
		System.out.println("Unordered Array");
		System.out.println(Arrays.toString(a));
		secureSort(a);
		System.out.println("Array after QuickSort3Way");
		System.out.println(Arrays.toString(a));
		System.out.println("Inverted Array");
		System.out.println(Arrays.toString(c));
		secureSort(c);
		System.out.println("Array after QuickSort3Way");
		System.out.println(Arrays.toString(c));

		System.out.println("Array with repeated elements");
		System.out.println(Arrays.toString(b));
		secureSort(b);
		System.out.println("Array after QuickSort3Way");
		System.out.println(Arrays.toString(b));

		System.out.println("Array already ordered");
		System.out.println(Arrays.toString(d));
		secureSort(d);
		System.out.println("Array after QuickSort3Way");
		System.out.println(Arrays.toString(d));
		System.out.println();

		var orderedTime = DoublingRatio.doublingRatio(TESTES, LENGTH, QuickSort3Way::orderedArray); // lambda
																									// expression:
																									// Method
																									// reference
		System.out.println("An ordered array is O(" + bigO(orderedTime.ratio) + ") worst case , real ratio = "
				+ orderedTime.ratio + " and it took " + orderedTime.time + " seconds");

		// around 0(N)
		var invertedTime = DoublingRatio.doublingRatio(TESTES, LENGTH, QuickSort3Way::invertedArray); // lambda
																										// expression:
																										// Method
																										// reference
		System.out.println("An inverted array is O(" + bigO(invertedTime.ratio) + ") worst case , real ratio = "
				+ invertedTime.ratio + " and it took " + invertedTime.time + " seconds");

		// around O(N)
		var partialTime = DoublingRatio.doublingRatio(TESTES, LENGTH, QuickSort3Way::partialArray); // lambda
																									// expression:
																									// Method
																									// reference
		System.out.println("An partially ordered array is O(" + bigO(partialTime.ratio) + ") worst case , real ratio = "
				+ partialTime.ratio + " and it took " + partialTime.time + " seconds");

		// around O(N)
		var unorderedTime = DoublingRatio.doublingRatio(TESTES, LENGTH, QuickSort3Way::unorderedArray); // lambda
																										// expression:
																										// Method
																										// reference
		System.out.println("An unordered array is O(" + bigO(unorderedTime.ratio) + ") worst case , real ratio = "
				+ unorderedTime.ratio + " and it took " + unorderedTime.time + " seconds");

		// around O(N)
		var lowRepeatedTime = DoublingRatio.doublingRatio(TESTES, LENGTH, QuickSort3Way::lowRepeatedArray); // lambda
																											// expression:
																											// Method
																											// reference
		System.out.println("An unordered array with low repeated elements is O(" + bigO(lowRepeatedTime.ratio)
				+ ") worst case , real ratio = " + lowRepeatedTime.ratio + " and it took " + lowRepeatedTime.time
				+ " seconds");

		// around O(N)
		var highRepeatedTime = DoublingRatio.doublingRatio(TESTES, LENGTH, QuickSort3Way::highRepeatedArray); // lambda
																												// expression:
																												// Method
																												// reference
		System.out.println("An unordered array with lots of repeated elements  is O(" + bigO(highRepeatedTime.ratio)
				+ ") worst case , real ratio = " + highRepeatedTime.ratio + " and it took " + highRepeatedTime.time
				+ " seconds");
	}
	
	///////// TRYING TO DO THE PROBLEM IN OTHER PERSPECTIVE BUT FORGET IT ///////////////

	/*public static <T extends Comparable<T>> int partition(T[] A, int inicio, int fim) {

		int meio = (inicio + fim) / 2;
		int a = (int) A[inicio];
		int b = (int) A[meio];
		int c = (int) A[fim];
		int medianaIndice;

		if (a < b) {
			if (b < c) {
				medianaIndice = meio;
			} else {
				if (a < c) {
					medianaIndice = fim;
				} else {
					medianaIndice = inicio;
				}
			}
		} else {
			if (c < b) {
				medianaIndice = meio;
			} else {
				if (c < a) {
					medianaIndice = fim;
				} else {
					medianaIndice = inicio;
				}
			}
		}
		exchange(A, medianaIndice, fim);
		T pivot = A[fim];
		int i = inicio - 1;
		for (int j = inicio; j <= fim - 1; j++) {	
			int cmp = A[j].compareTo(pivot);
			if (cmp <= 0) {
				i += 1;
				exchange(A, i, j);
			}
		}
		exchange(A, i + 1, fim);
		return i + 1; //retorna a posicao do pivo
	}

	public static <T extends Comparable<T>> void quicksortMedianaDeTres(T[] A, int inicio, int fim) {
		if (inicio < fim) {
			// realiza a particao
			int q = partition(A, inicio, fim);
			// ordena a particao esquerda
			quicksortMedianaDeTres(A, inicio, q - 1);
			// ordena a particao direita
			quicksortMedianaDeTres(A, q + 1, fim);
		}
	}
	
	public static <T extends Comparable<T>> void quicksortMedianaDeTres(T[] A) {
		 quicksortMedianaDeTres(A, 0, A.length - 1);
	}*/

	public static <T extends Comparable<T>> void sort(T[] a) {
		shuffle(a);
		sort(a, 0, a.length - 1);
	}

	public static <T extends Comparable<T>> void sort(T[] a, int lo, int hi) {


		while (hi - lo < 80) {
			InsertionSort.sort(a, lo, hi);
			return;
		}

		if (hi < lo)
			return;

		int mid = (hi - lo) / 2 + lo;

		// order lo , mid , hi on the array
		if (less(a[hi], a[lo]))
			exchange(a, hi, lo);
		if (less(a[mid], a[lo]))
			exchange(a, mid, lo);
		if (less(a[hi], a[mid]))
			exchange(a, mid, hi);

		exchange(a, mid, lo);

		int lt = lo, i = lo + 1, gt = hi;
		T key = a[lo];

		while (i <= gt) {//percorre o array
			int cmp = a[i].compareTo(key);
			if (cmp < 0)
				exchange(a, lt++, i++);
			else if (cmp > 0)
				exchange(a, i, gt--);
			else
				i++;
		}
		sort(a, lo, lt - 1);
		sort(a, gt + 1, hi);
	}

	private static class InsertionSort extends Sort {
		public static <T extends Comparable<T>> void sort(T[] a, int start, int end) {
			int n = end;
			for (int i = start + 1; i <= n; i++) {
				for (int j = i; j > start && less(a[j], a[j - 1]); j--)
					exchange(a, j, j - 1);
			}

		}
	}

	///////////////////////////////////// TIME TO RUN
	///////////////////////////////////// /////////////////////////////////////

	private static class Stopwatch {
		private final long start;

		public Stopwatch() {
			start = System.currentTimeMillis();
		}

		public double elapsedTime() {
			long now = System.currentTimeMillis();
			return (now - start) / 1000.0;
		}
	}

	private static class DoublingRatio {
		public static double timeTrial(int N, ArrayGenerator generator) {
			Integer[] a = generator.generate(N);
			var stopwatch = new Stopwatch();
			sort(a);
			return stopwatch.elapsedTime();
		}

		// N is number of times , M is length of the array
		public static TimeAndRatio doublingRatio(int N, int M, ArrayGenerator generator) {
			double currentTime = 0.0;
			double halfTime = 0.0;
			for (int i = 0; i < N; i++) {
				halfTime += timeTrial((M / 2), generator);
				currentTime += timeTrial(M, generator);
			}
			return new TimeAndRatio(halfTime + currentTime, currentTime / halfTime);
		}
	}

	///////////////////////// TYPES OF ARRAYS /////////////////////

	private static Integer[] orderedArray(int n) {
		var a = new Integer[n];
		for (int i = 0; i < n; i++)
			a[i] = i;
		return a;
	}

	private static Integer[] invertedArray(int n) {
		var a = new Integer[n];
		for (int i = 0; i < n; i++)
			a[i] = n - i - 1;
		return a;
	}

	private static Integer[] partialArray(int n) {
		var a = orderedArray(n);
		int length = n / 8;
		Random r = new Random();

		for (int i = 0; i < length; i++) {
			exchange(a, r.nextInt(n), r.nextInt(n));
		}
		return a;
	}

	private static Integer[] unorderedArray(int n) {
		var a = orderedArray(n);
		shuffle(a);
		return a;
	}

	private static Integer[] lowRepeatedArray(int n) {
		var a = new Integer[n];
		var r = new Random();
		int allowedElements = 10000;
		for (int i = 0; i < n; i++) {
			a[i] = r.nextInt(allowedElements);
		}
		return a;
	}

	private static Integer[] highRepeatedArray(int n) {
		var a = new Integer[n];
		var r = new Random();
		int allowedElements = 10;
		for (int i = 0; i < n; i++) {
			a[i] = r.nextInt(allowedElements);
		}
		return a;
	}

	private static <T extends Comparable<T>> void shuffle(T[] a) {
		Random r = new Random();

		for (int i = a.length - 1; i > 0; i--) {
			int j = r.nextInt(i + 1);
			exchange(a, i, j);
		}
	}

	private static void shuffle(Integer[] a) {
		Random r = new Random();

		for (int i = a.length - 1; i > 0; i--) {
			int j = r.nextInt(i + 1);
			exchange(a, i, j);
		}
	}

	private static <T extends Comparable<T>> void secureSort(T[] a) {
		sort(a);
		if (!isSorted(a))
			throw new IllegalStateException();
	}

	private static String bigO(double ratio) {
		int n = (int) Math.round(ratio);
		switch (n) {
		case 0:
			return "1";
		case 1:
			return "N";
		case 2:
			return "N^2";
		case 3:
			return "N^3";
		default:
			return "1";
		}
	}

	private static double bigOExponent(double time) {
		return Math.log(time) / Math.log(2);
	}

	public interface ArrayGenerator {
		public Integer[] generate(int n);
	}

	private static class TimeAndRatio {
		double time;
		double ratio;

		TimeAndRatio(double time, double ratio) {
			this.time = time;
			this.ratio = bigOExponent(ratio);
		}
	}

}
