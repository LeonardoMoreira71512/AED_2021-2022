public class ContaBancaria
{
    private double saldo;
    private long NIB;

    public ContaBancaria(long nib) {
        NIB = nib;
        saldo = 0;
    }

    public ContaBancaria(long nib, double saldo) {
        NIB = nib;
        saldo = 0;
    }

    public long getNIB()
    {
        return this.NIB;
    }

    public double getSaldo()
    {
        return this.saldo;
    }

    public void levantamento(double valor)
    {
        if(saldo >= valor)
        {
            saldo -= valor;
        }
    }

    public void deposito(double valor)
    {
        if(valor > 0)
        {
            saldo += valor;
        }
    }
}
