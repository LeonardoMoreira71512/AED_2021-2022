import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

public class Main {
	
	//Faz parte do Exerc�cio 1.1.2
	public static ContaBancaria copiaConta(ContaBancaria c)
	{ 
		ContaBancaria c1 = new ContaBancaria(c.getNIB(),c.getSaldo()); //Obj2 
		ContaBancaria c2 = new ContaBancaria(c1.getNIB(),c1.getSaldo());//Obj3
		return c1; 
	}
	
	//Exerc�cio 1.1.4 (a) implementa��o de uma vers�o recursiva da fun��o factorial
	public static int factorialRecursivo(int n)
	{
		//condi��o de paragem
		if(n<=1) return 1;
		
		return n * factorialRecursivo(n-1);
	}
	
	//Exerc�cio 1.1.4 (b) implementa��o de uma vers�o n�o recursiva (iterativa) da fun��o factorial
	public static int factorialIterativo(int n)
	{
		int res = 1;
		
		while(n > 1)
		{
			res = res * n;
		}
		
		return res;
	}
	
	//Exerc�cio 1.1.5 - Implementa��o simples de um m�todo que filtra uma lista
	public static List<Integer> filtraLista(List<Integer> lista)
	{
		//precisamos de uma nova lista onde colocar os elementos filtrados
		//List<Integer> � uma interface, precisamos de usar uma classe que implementa a interface List
		List<Integer> novaLista = new ArrayList<Integer>();
		
		//usando um foreach para percorrer a lista original
		for(Integer i : lista) 
		{
			if(i < 10) novaLista.add(i);
		}
		
		//se quisermos percorrer a lista usando um �ndice e um iterador, como se faz em C, podemos fazer o seguinte
		//for(int i = 0; i < lista.size(); i++)
		//{
			//esta pode n�o ser a forma mais eficiente, porque o segundo get � desnecess�rio
		//	if(lista.get(i)<10) novaLista.add(lista.get(i));	
		//}
		
		return novaLista;
	}
	
	//Exerc�cio 1.1.6 - Implementa��o de um m�todo que filtra uma lista usando generics e m�todos de ordem superior
	//Em Java, m�todos de ordem superior s�o usados atrav�s de interfaces, e refer�ncias(ponteiros) para m�todos
	//Nesta caso estamos a usar a interface Predicate<T> que tem um m�todo designado test, que recebe um argumento do tipo T
	//e que devolve true ou false
	public static <T> List<T> filtraLista(List<T> lista, Predicate<T> pred)
	{
		//precisamos de uma nova lista onde colocar os elementos filtrados
		//List<Integer> � uma interface, precisamos de usar uma classe que implementa a interface List
		List<T> novaLista = new ArrayList<T>();
		
		//usando um foreach para percorrer a lista original
		for(T t : lista) 
		{
			if(pred.test(t)) novaLista.add(t);
		}
				
		return novaLista;
	}
	
	
	
	//Exerc�cio 1.1.7 - Pretende-se que os alunos aprendam a usar o mecanismo de depura��o (debugging) do Eclipse para tentar perceber onde poder� estar o erro
	public static void sattoloShuffle(Object[] a) {
        int n = a.length;
        for (int i = n; i > 1; i--) {
            // choose index uniformly in [0, i-1[
            int r = (int) (Math.random() * (i-1));
            //o erro est� nas pr�ximas duas linhas, n�o se pode trocar com r-1 (r pode ser 0), mas sim com r
            Object swap = a[r-1];
            a[r-1] = a[i-1];
            a[i-1] = swap;
        }
    }
	
	public static int euclides(int x, int y)
	{
		while(x != y) 
		{
			if(x < y) y -= x;
			else x -= y;
		}
		return x;
	}
	
	public static void main(String[] args)
    {
		//Exerc�cio 1.1.1
		String string1 = "hello";
		String string2 = string1;
		string1 = "world";
		System.out.println(string1); System.out.println(string2);
		
		//Exerc�cio 1.1.2
		ContaBancaria c1;
		ContaBancaria c2;
		ContaBancaria c3;
		
		c1 = new ContaBancaria(2039958123,200); //obj 1
		c2 = copiaConta(c1);
		c1 = new ContaBancaria(1231488393,150); //obj 4
		c3 = c1;
		c1 = null;
		//o objetivo deste exerc�cio � perceber quais os objectos que v�o ser marcados como lixo, depois da �ltima linha ser executada.
		//Foram criados 4 objectos do tipo conta no Heap. Obj1 � criado pela 1.� instru��o
		//Os obj2 e obj3 s�o criados na invoca��o do m�todo copia conta, mas o obj3 como n�o � retornado, a refer�ncia para ele � perdida, e � marcado para remo��o.
		//O obj2 � guardado na vari�vel c2.
		//a instru��o c1= new ContaBancaria(1231488393,150); vai criar um novo objecto, mas vai apagar a refer�ncia ao obj1, que ir� ser marcado como lixo
		//a vari�vel c3 tem uma refer�ncia ao objecto 4
		//a �ltima instru��o vai eliminar uma das refer�ncias ao obj4, mas como ainda existe uma refer�ncia (c3) para o obj4, este n�o � marcado como lixo
		//resumindo, obj1 e obj3 s�o marcados como lixo, obj2 e obj4 n�o.
		
		
		//Exerc�cio 1.1.3 (a)
		System.out.println("Hello World!");
		System.out.println(args[0]);
		
		
		//Exerc�cio 1.1.6 - Ilustra��o de como se invoca um m�todo de ordem superior usando  uma fun��o lambda
		ArrayList<Integer> lista = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5,6,7,8,9,10));
		//chama o m�todo filtra lista, com uma fun��o lambda que retorna true se o elemento for par, e false se for impar.
		// el -> (el % 2) == 0 � uma fun��o lambda, com um �nico argumento el, que retorna o resultado da express�o (el % 2) == 0
		List<Integer> listaFiltrada = filtraLista(lista, el -> (el % 2) == 0);
				
        System.out.println(listaFiltrada);
        
        String[] a = {"isto","�","uma","lista","de","palavras","a","baralhar"}; 
        sattoloShuffle(a);
        for (int i = 0; i < a.length; i++) 
        	System.out.println(a[i]);
        
        //Exerc�cio 1.1.8
        //Existem v�rias formas de ler um ficheiro em Java, incluindo BufferedReaderm ou StreamReaders,
        //No entanto neste exerc�cio vamos usar um scanner, que � uma funcionalidade de JDKs mais recentes
        
        //vamos assumir que o nome do ficheiro � passado no argumento 0
        
        String line;
        String tokens[];
        Scanner input;
        //temos de criar um objecto que vai ser respons�vel por abrir e gerir o ficheiro. Isto � feito pela classe File.
        File file = new File(args[0]);
        
        //Um scanner � um objecto que tem uma s�rie de m�todos para ler informa��o de uma stream (que pode ser um ficheiro)
        try {
        	input = new Scanner(file);
        	
        	 //vamos ler linha a linha
            while(input.hasNextLine())
            {
            	//l� a pr�xima linha
            	line = input.nextLine();
            	//um ficheiro csv tem as colunas separadas por ",", vamos usar o m�todo split que devolve um array de strings
            	tokens = line.split(",");
            	//imprimir a segunda coluna
            	System.out.println(tokens[1]);
            	
            }
        }
        catch (IOException e)
        {
        	System.out.println("File not found");
        	e.printStackTrace();
        }
        
        //Exerc�cio 1.1.9
        //De acordo com as barreiras de abstra��o de dados, deve haver uma separa��o entre a representa��o de um tipo de dados
        //e a sua utiliza��o. Ou sera, o programador que usa o TAI n�o deve saber como este est� implementado. Isto permite que mais 
        //tarde o TAI possa mudar a sua implementa��o sem afetar o c�digo que usa esse TAI.
        //No caso particular do c�digo apresentado no exerc�cio 1.1.9 n�o s�o respeitadas as barreiras de abstra��o, pois
        //os atributos da classe s�o declarados como publicos e usados directamente pela fun��o main, quebrando desta forma
        //as barreiras de abstra��o.
    }
}
