package aed.tables;

import java.util.*;

/**
 * Treap is randomized binary search tree. Easiest way to randomize would be to
 * get all elements in array and then after random permutation insert them all.
 * However that would require to know all elements in advance. Treap solves this
 * by introducing additional variable to its node - priority which is generated
 * randomly.
 *
 * @author Leonardo Moreira 71512
 * @created December 10, 2021
 * 
 * Some sources i used to do the project:
 * 
 * @see https://tutoria.ualg.pt/2021/pluginfile.php/152580/mod_resource/content/1/Aula%2015%20-%20%C3%81rvores%20de%20Pesquisa%20Bin%C3%A1ria.pdf
 * @see https://tutoria.ualg.pt/2021/pluginfile.php/150173/mod_resource/content/1/Aula%2016%20-%20%C3%81rvores%20de%20Pesquisa%202-3.pdf
 * @see https://tutoria.ualg.pt/2021/pluginfile.php/152584/mod_resource/content/1/Aula%2017%20-%20%C3%81rvores%20Red-Black.pdf
 * @see https://www.youtube.com/watch?v=6podLUYinH8
 * @see https://www.youtube.com/watch?v=t0Cq6tVNRBA
 */

public class Treap<Key extends Comparable<Key>,Value> {

	Node root = null;
	Random r;
	
	public static void main(String[] args) {
		
		Treap<Integer, Integer> treap = new Treap<>(new Random());
		
		final int LENGTH = 20000000; //these must have to be a large number so they could pass at test efficiency
		final int N = 1000000;
		
		treap.put(15, 2);
		treap.put(12, 5);
		treap.put(3, 14);
		treap.put(5, 9);
		treap.put(19, 4);
		treap.put(10, 7);
		treap.put(22, 2);
		treap.put(104, 16);
		treap.put(0, 15);
		treap.put(500, 35);
		treap.put(75, 27);
		treap.put(58, 93);
		
		System.out.println();
		
		
		System.out.println("\t\t\t\t\t\t     ORIGINAL TREAP  \n");
		treap.printTreapBeginning(); //prints the first 5 levels of the treap
		System.out.println();
		System.out.println();
		System.out.println("\t\t\t\t\t\tTREAP AFTER SOME DELETES  \n");
		
		treap.delete(15);
		treap.delete(14);
		treap.delete(13);
		treap.delete(22);
		treap.delete(1);
		//treap.delete(3);
		//treap.delete(5);
		//treap.delete(10);
		//treap.delete(22);
		treap.printTreapBeginning();
			
		var copy = treap.shallowCopy();

		System.out.println(" \n\n\t\t\t\t\t\t      Shallow Copy  \n");

		copy.printTreapBeginning();
		
		System.out.println("\n\n\t\t\t\t\t\t      TREAP SPLIT   ");
		
		var splitTreap = treap.split(20);
		
		var treap1 = splitTreap[0];
		var treap2 = splitTreap[1];
		System.out.println(" \n\t\t\t\t\t\t        split 1  \n");
		treap1.printTreapBeginning();

		System.out.println(" \n\t\t\t\t\t\t        split 2  \n");

		treap2.printTreapBeginning();
		
		System.out.println();
		System.out.println();
		
		System.out.print(" ---------- ITERATORS ----------");
		System.out.print("\n\nIterator treap.keys() = ");
		for (Integer p : treap.keys()) {
			System.out.print(p + " ");
		}
		
		System.out.println();

		System.out.print("Iterator treap.keys(2,20) = "); //puts in a linkedList all the keys that are between the keys given
		for (Integer p : treap.keys(2, 20)) {
			System.out.print(p + " ");
		}
		
		System.out.println();

		System.out.print("Iterator treap.values = ");
		for (Integer p : treap.values()) {
			System.out.print(p + " ");
		}
		
		System.out.println();

		System.out.print("Iterator treap.priorities = ");
		for (Integer p : treap.priorities()) {
			System.out.print(p + " ");
		}

		System.out.println();

		System.out.println();
		System.out.println();
		System.out.println("Is the key '104' present? " + treap.containsKey(104) + "\t\t\t\t\t\t\t |");
		System.out.println("Is the key '7' present? " + treap.containsKey(7) + "\t\t\t\t\t\t\t |");
		
		System.out.println("Size of the treap: " + treap.size() + "\t\t\t\t\t\t\t\t |"); //return the number of pairs (key-value)
		System.out.println("Number of keys that exist between the key 0 and 500: " + treap.size(0,500) + "\t\t\t\t |"); //return the number of keys
		
		System.out.println("get method for the number '19': " + treap.get(19) + "\t\t\t\t\t\t |"); //get should return the value of the key given
		System.out.println("get method for the number '7': " + treap.get(7) + "\t\t\t\t\t\t |");
		
		System.out.println("getNode method for the Pair(root, '12'): " + treap.getNode(treap.root, 12) + "\t\t |"); //get should return the value of the key given
		System.out.println("getNode method for a key that doesn't exist: " + treap.getNode(treap.root, 14) + "\t\t\t\t |");
		
		System.out.println("Select method for the number 3: " + treap.select(3));
		System.out.println("Select method for the number 0: " + treap.select(0));
		System.out.println("rank method for number '15': " + treap.rank(15) + "\t\t\t\t\t\t\t |"); //should return the number of keys that are lower than the input number
		System.out.println("_________________________________________________________________________________");
		
		
		var arr1 = orderedArray(LENGTH);
		
		
//////////////////////////////////////// get orderedArray /////////////////////////////////

		
		// log(N)
		var half = DoublingRatio.timeTrialGet(fillTreap(arr1, 1000), 1000, N);

		System.out.println("\n ORDERED GET DOUBLING TEST \n");
		for (int i = 2000; i < LENGTH; i += i) {
			var time = DoublingRatio.timeTrialGet(fillTreap(arr1, i), i, N);
			var getOrderedTime = new TimeAndRatio(time, time/half);
			half = time;

			System.out.println(
					"An getOrdered for " + i + "  is O(" + bigO(getOrderedTime.ratio) + ") worst case , real ratio = "
							+ getOrderedTime.ratio + " and it took " + getOrderedTime.time + " seconds");
		}
		
		
/////////////////////////////////////// get unorderedArray ////////////////////////////////

		arr1 = unorderedArray(LENGTH);

//log(N)
		half = DoublingRatio.timeTrialGet(fillTreap(arr1, 1000), 1000, N);

		System.out.println("\n UNORDERED GET DOUBLING TEST \n");
		for (int i = 2000; i < LENGTH; i += i) {
			var time = DoublingRatio.timeTrialGet(fillTreap(arr1, i), i, N);
			var getUnorderedTime = new TimeAndRatio(time, time / half);
			half = time;

			System.out.println("A getUnordered for " + i + "  is O(" + bigO(getUnorderedTime.ratio)
					+ ") worst case , real ratio = " + getUnorderedTime.ratio + " and it took " + getUnorderedTime.time
					+ " seconds");
		}
		
//////////////////////////////////////// PUT ////////////////////////////////////////////

		arr1 = orderedArray(LENGTH);
		// log(N)
		half = DoublingRatio.timeTrialPut(fillTreap(arr1, 1000), 1000, N);

		System.out.println("\n PUT DOUBLING TEST \n");
		for (int i = 50000; i < LENGTH; i += i) {
			var time = DoublingRatio.timeTrialDelete(fillTreap(arr1, i), i, N);
			var putTime = new TimeAndRatio(time, time / half);
			half = time;

			System.out.println("A put for " + i + "  is O(" + bigO(putTime.ratio) + ") worst case , real ratio = "
					+ putTime.ratio + " and it took " + putTime.time + " seconds");
		}
		
/////////////////////////////////////// DELETE //////////////////////////////////////////
		
		 //log(N)
	      half = DoublingRatio.timeTrialPut(fillTreap(arr1,1000),1000,N);

	      System.out.println("\n DELETE DOUBLING TEST \n");
	      for(int i = 2000; i < LENGTH ; i+= i) {
	         var time = DoublingRatio.timeTrialPut(fillTreap(arr1, i),i,N);
	         var deleteTime = new TimeAndRatio(time,time/half);
	         half = time;

	         System.out.println("A delete for " + i +  "  is O(" + bigO(deleteTime.ratio) + ") worst case , real ratio = " + deleteTime.ratio +
	                 " and it took " + deleteTime.time + " seconds");
	      }

}
	
	
//////////////////////////////////////// NODE /////////////////////////////////////////
	
	
    private class Node
    {
        private Key key;
        private int priority;
        private Value value;
        private Node left;
        private Node right;
        private int size;
 
        public Node(Key k, Value v, int size, int priority)
        {
            this.key = k;
            this.value = v;
            this.size = size;
            this.priority = priority;
        }
        
        public String toString()
        {
        	return "[k:" + this.key + " v:" + this.value + " p:" + this.priority + " s:" + this.size + "]";
        }
        
        public Node shallowCopy() {
            return new Node(key, value, size, priority);
        }
    }
    
    
    ////////////////////////////////////////////////////////////////////////////////////////
    
    
    
    //Function that inserts a certain number of elements in a treap
     private static Treap<Integer,Integer> fillTreap(Integer[] a, int n){
		      var treap = new Treap<Integer,Integer>();
		      for(int i = 0; i < n; i++)
		         treap.put(i,0);
		      return treap;
	}
     
    //DEFAULT FUNCTION
    public Treap(){
    	this.r = new Random(100);
    }
    
    public Treap(Random r){
    	this.r = r;
    }
   
    //RETURNS CURRENT NODE N SIZE, IT'S MAIN USE IT'S FOR UPDATES TO SIZE WHEN IT'S SONS EXCHANGE
    private int size(Node n) {
        if (n == null) return 0;
        int rightSize = (n.right == null) ? 0 : n.right.size;
        int leftSize = (n.left == null) ? 0 : n.left.size;
        return rightSize + leftSize + 1;
    }

    // RETORNA O NUMERO DE PARES CHAVE-VALOR GUARDADOS NO TREAP
    public int size() {
    	if(root == null)
    		return 0;
        return root.size;
    }
    
     /**
	 * caso o no esteja vazio retorna null caso a chave seja menor q chave do no
	 * procura no no esquerdo else procura no no direito caso k seja igual a chave
	 * do no retorna o valor guardado no no
	 */
    public Value get(Key k)
    {
    	return get(this.root, k);
    }
    
    //get helper method
	private Value get(Node n, Key k) {
		if (n == null)
			return null;
		int cmp = k.compareTo(n.key);
		if (cmp < 0)
			return get(n.left, k);
		else if (cmp > 0)
			return get(n.right, k);
		else
			return n.value;
	}
	
	private Node getNode(Node n, Key k) {
		if(n == null)
			return null;
		
		int cmp = k.compareTo(n.key);
		if(cmp < 0)
			return getNode(n.left, k);
		else if(cmp > 0)
			return getNode(n.right, k);
		return n;
	}

	
    public boolean containsKey(Key k)
    {
        return get(k) != null; //se souber q o get da respetiva chave e null ent sei q essa chave n existe na treap
    }
    
 // AUXILIAR METHODS TO DO THE ROTATION OF NODES
    private Node rotate(Node n) {
    	if(n.size == 1) //can't rotate with just 1 node
    		return n;
    	if(n.left == null || n.right == null) {
    		if(n.left == null && n.priority < n.right.priority)
    			return rotateLeft(n);
    		else if(n.right == null && n.priority < n.left.priority)
    			return rotateRight(n);
    	}
    	else {
    		//if both aren't null then rotate with the child that as the highest priority
    		if(n.right.priority > n.left.priority) {
    			if(n.priority < n.right.priority)
    				return rotateLeft(n);
    		}
    		else if(n.priority < n.left.priority)
    			return rotateRight(n);
    	}
    	return n;
    }
    
 	private Node rotateLeft(Node father) {
 		Node newFather = father.right;
 		father.right = newFather.left;
 		newFather.left = father;

 		//updates the size
 		father.size = size(father);
 		newFather.size = size(newFather);

 		// set a new father
 		return newFather;
 	}
 	
 	private Node rotateRight(Node father) {
 		Node newFather = father.left;
 		father.left = newFather.right;
 		newFather.right = father;

 		//updates the size
 		father.size = size(father);
 		newFather.size = size(newFather);

 		// set a new father
 		return newFather;
 	}

    public void put(Key k, Value v) {
    	if(v == null) {
    		delete(k);
    		return;
    	}
		root = put(root, k, v);
	}
    
	    private Node put(Node current, Key k, Value v) {
	    	if (current == null)
				return new Node(k, v, 1, r.nextInt());
	    	
			int cmp = k.compareTo(current.key);
			if (cmp < 0) {
				current.left = put(current.left, k, v);
			} 
			else if(cmp > 0){
				current.right = put(current.right, k, v);
			}
			else {
				current.value = v;
			}
			
			// update the node size
			current.size = size(current);
			return rotate(current);
	    }
    
   
	@SuppressWarnings("unused")
	private Node splitPut(Node current, Key k) {
    	if(current == null)
    		return new Node(k, root.value,1,Integer.MAX_VALUE);
    	
    	int cmp = k.compareTo(current.key);
    	if(cmp < 0)
    		current.left = splitPut(current.left, k);
    	else if(cmp > 0)
    		current.right = splitPut(current.right, k);
    	else current.priority = Integer.MAX_VALUE;
    	
    	current.size = size(current);
    	return rotate(current);
     }
	
	@SuppressWarnings("rawtypes")
	public Treap[] split(Key k){
    	root = splitPut(root, k);
    	
    	@SuppressWarnings("unchecked")
		Treap<Key, Value>[] treapSplit = new Treap[2];
    	
    	treapSplit[0] = new Treap<>(r);
    	treapSplit[0].root = root.left;
    	treapSplit[1] = new Treap<>(r);
    	treapSplit[1].root = root.right;
    	
    	return treapSplit;
    }
    
    //if k doesn't exist it could be more efficient
    public void delete(Key k)
    {
    	Node n = getNode(root,k);
    	if(n == null) return; //the key doesn't exist
    			
    	n.priority = Integer.MIN_VALUE; //sets the node with the lowest priority
    	
    	root = delete(root, k);
    }
    
    private Node delete(Node current, Key k) {
    	if(current.size == 1)
    		return null;
    	
    	int cmp = k.compareTo(current.key);
    	if(cmp == 0) {
    		current = rotate(current);
    		cmp = k.compareTo(current.key);
    	}
    	
    	if(cmp < 0)
    		current.left = delete(current.left, k);
    	else if(cmp > 0)
    		current.right = delete(current.right, k);
    	current.size = size(current);
    	return current;
    }

   

    public Key min()
    {
        Node current = root;
        if(current == null)
        	return null;
        while(current.left != null)
        	current = current.left;
        return current.key;
    }

    public Key max()
    {
    	Node current = root;
        if(current == null)
        	return null;
        while(current.right != null)
        	current = current.right;
        return current.key;
    }
    
    public void deleteMin() {
       if(root == null)
    	   return;
       if(root.left == null) {
    	   delete(root.key);
    	   return;
       }
       
       Node n = root;
       while(n.left.left != null) {
    	   n.size--;
    	   n = n.left;
       }
       
       n.left = n.left.right;
       n.size--;
    }
    
    public void deleteMax()
    {
    	   if(root == null)
        	   return;
           if(root.right == null) {
        	   delete(root.key);
        	   return;
           }
           
           Node n = root;
           while(n.right.right != null) {
        	   n.size--;
        	   n = n.right;
           }
           
           n.right = n.right.left;
           n.size--;
    }

    public int rank(Key k){
        return rank(root, k);
    }
    
    private int rank(Node n, Key k) {
    	if(n == null) return 0;
    	int cmp = k.compareTo(n.key);
    	if(cmp < 0)
    		return rank(n.left, k);
    	else if(cmp > 0)
    		return size(n.left) + 1 + rank(n.right,k);
    	else return size(n.left);
    }
    
    public int size(Key min, Key max){
    	if(min.compareTo(max) > 0)
    		return 0;
    	int between = rank(max) - rank(min);
    	return between + ((get(max) == null) ? 0 : 1);
    }
    
    public Key select(int n){
        return select(root, n);
    }
    
    private Key select(Node n, int k) {
    	if(n == null)
    		return null;
    	int subRank = size(n.left);
    	int cmp = k - subRank;
    	if(cmp > 0)
    		return select(n.right, k - subRank - 1);
    	else if(cmp < 0)
    		return select(n.left, k);
    	return n.key;    
    }
    
    
    public Iterable<Key> keys(){
        return new KeyIterable();
    }
    
    public Iterable<Value> values()
    {
        return new ValueIterable();
    }
    
    public Iterable<Integer> priorities()
    {
        return new PriorityIterable();
    }
    
    public Iterable<Key> keys(Key min, Key max)
    {
        return new KeyIterable(min,max);
    }
    
    @SuppressWarnings({ })
	public Treap<Key,Value> shallowCopy()
    {
    	var copy = new Treap<Key,Value>();
    	copy.root = treapShallowCopy(root);
    	return copy;
    }
    
    private Node treapShallowCopy(Node n) {	
    	if(n == null)
    		return null;
    	Node copy = n.shallowCopy();
    	copy.left = treapShallowCopy(n.left);
    	copy.right = treapShallowCopy(n.right);
    	return copy;
    }
    
    
    ///////////////////////////////////// ITERATOR'S ////////////////////////////////////////////////////////
    
    ///////////////////////////////////// KEY'S ITERATOR ////////////////////////////////////////////////////
    
    private LinkedList<Node> treapList(Key min, Key max){
    	if(size() == 0)
    	    return new LinkedList<Node>();
        Node n = root;
        while(n.right != null && min.compareTo(n.key) > 0)
           n = n.right;

        return treapList(new LinkedList<Node>(),n,min,max);
    }
    
    private LinkedList<Node> treapList(LinkedList<Node> linkedList,Node n,Key min,Key max){
        if(n == null ) return linkedList;
        if( min.compareTo(n.key) > 0)
           return treapList(linkedList,n.right,min,max);
        if(n.left != null) treapList(linkedList,n.left,min,max);
        if(max.compareTo(n.key) >= 0){
           linkedList.add(n);
           treapList(linkedList,n.right,min,max);
        }
        return linkedList;
     }
    
		@SuppressWarnings("unused")
		private class KeyIterable implements Iterable<Key> {
			
			final private Iterator<Key> iteratorObj;

			@SuppressWarnings("unused")
			KeyIterable() {
				iteratorObj = new KeyIterator();
			}

			KeyIterable(Key min, Key max) {
				iteratorObj = new KeyIterator(min, max);
			}

			public Iterator<Key> iterator() {
				return iteratorObj;
			}
		}

		private class KeyIterator implements Iterator<Key> {
			Iterator<Treap<Key, Value>.Node> iterator;

			KeyIterator() {
				iterator = treapList(min(), max()).iterator();
			}

			KeyIterator(Key min, Key max) {
				iterator = treapList(min, max).iterator();
			}

			public boolean hasNext() {
				return iterator.hasNext();
			}

			public Key next() {
				return iterator.next().key;
			}
		}
    
    ///////////////////////////////////// VALUES ITERATOR ///////////////////////////////////////////////////
    
    
	private class ValueIterable implements Iterable<Value> {

		public Iterator<Value> iterator() {
			return new ValueIterator();
		}
	}

	private class ValueIterator implements Iterator<Value> {

		Iterator<Treap<Key, Value>.Node> iterator;

		ValueIterator() {
			iterator = treapList(min(), max()).iterator();
		}

		public boolean hasNext() {
			return iterator.hasNext();
		}

		public Value next() {
			return iterator.next().value;
		}
	}
	
	
	///////////////////////////////////// PRIORITY ITERATOR /////////////////////////////////////////////////
	
	
	@SuppressWarnings("unused")
	private class PriorityIterable implements Iterable<Integer> {
		public Iterator<Integer> iterator() {
			return new PriorityIterator();
		}
	}

	private class PriorityIterator implements Iterator<Integer> {
		Iterator<Treap<Key, Value>.Node> iterator;

		PriorityIterator() {
			iterator = treapList(min(), max()).iterator();
		}

		public boolean hasNext() {
			return iterator.hasNext();
		}

		public Integer next() {
			return iterator.next().priority;
		}
	}
	///////////////////////////////////// TESTING TIME EFFICIENCY ///////////////////////////////////////////
	
	private static class Stopwatch {
		private final long start;

		public Stopwatch() {
			start = System.currentTimeMillis();
		}

		public double elapsedTime() {
			long now = System.currentTimeMillis();
			return (now - start) / 1000.0;
		}
	}
	
	@SuppressWarnings("unused")
	private static class DoublingRatio {

		public static double timeTrialGet(Treap<Integer, Integer> treap, int A, int B) {
			var r = new Random();
			var stopwatch = new Stopwatch();
			for (int i = 0; i < B; i++)
				treap.get(r.nextInt(A));
			return stopwatch.elapsedTime();
		}
		
		 //A is range were we know that a key has been put , and B is the number of times we put it .
	      public static double timeTrialPut(Treap<Integer,Integer> treap,int A,int B){
	         var r = new Random();
	         var stopwatch = new Stopwatch();
	         for(int i = 0; i < B; i++)
	            treap.put(A + r.nextInt(A),i);
	         return stopwatch.elapsedTime();
	      }
		
		 //A is range in which we delete keys , and B is the number of times we delete it .
	      public static double timeTrialDelete(Treap<Integer,Integer> treap,int A,int B){
	         var r = new Random();
	         var stopwatch = new Stopwatch();
	         for(int i = 0; i < B; i++)
	            treap.delete(r.nextInt(A));
	         return stopwatch.elapsedTime();
	      }
	}
	
	@SuppressWarnings("unused")
	private interface ArrayGenerator {
		public Integer[] generate(int N);
	}

	private static Integer[] orderedArray(int N) {
		var a = new Integer[N];
		for (int i = 0; i < N; i++)
			a[i] = i;
		return a;
	}

	@SuppressWarnings("unused")
	private static Integer[] unorderedArray(int N) {
		var a = orderedArray(N);
		shuffle(a);
		return a;
	}

	private static <T extends Comparable<T>> void shuffle(T[] a) {
		Random r = new Random();

		for (int i = a.length - 1; i > 0; i--) {
			int j = r.nextInt(i + 1);
			exchange(a, i, j);
		}
	}

	protected static <T extends Comparable<T>> void exchange(T[] a, int i, int j) {
		T t = a[i];
		a[i] = a[j];
		a[j] = t;
	}

	@SuppressWarnings("unused")
	private static String bigO(double ratio) {
		int n = (int) Math.round(ratio);
		switch (n) {
		case 0:
			return "1";
		case 1:
			return "N";
		case 2:
			return "N^2";
		case 3:
			return "N^3";
		default:
			return "1";
		}
	}

	private static double bigOExponent(double time) {
		return Math.log(time) / Math.log(2);
	}

	@SuppressWarnings("unused")
	private static class TimeAndRatio {
		double time;
		double ratio;

		TimeAndRatio(double time, double ratio) {
			this.time = time;
			this.ratio = bigOExponent(ratio);
		}
	}
    
    ///////////////////////////////////// TEACHER STUFF /////////////////////////////////////////////////////


    //helper method that uses the treap to build an array with a heap structure
    private void fillHeapArray(Node n, Object[] a, int position)
    {
    	if(n == null) return;

    	if(position < a.length)
    	{
    		a[position] = n;
        	fillHeapArray(n.left,a,2*position);
        	fillHeapArray(n.right,a,2*position+1);
    	}
    }

    //if you want to use a different organization that a set of nodes with pointers, you can do it, but you will have to change
    //this method to be consistent with your implementation
	private Object[] getHeapArray()
    {
    	//we only store the first 31 elements (position 0 is not used, so we need a size of 32), to print the first 5 rows of the treap
    	Object[] a = new Object[32];
    	fillHeapArray(this.root,a,1);
    	return a;
    }
    
    private void printCentered(String line)
    {
    	//assuming 120 characters width for a line
    	int padding = (120 - line.length())/2;
    	if(padding < 0) padding = 0;
    	String paddingString = "";
    	for(int i = 0; i < padding; i++)
    	{
    		paddingString +=" ";
    	}
    	
    	System.out.println(paddingString + line);
    }

    //this is used by some of the automatic tests in Mooshak. It is used to print the first 5 levels of a Treap.
    public void printTreapBeginning() {
        Object[] heap = getHeapArray();
        int size = size(this.root);
        int printedNodes = 0;
        String nodeToPrint;
        int i = 1;
        int nodes;
        String line;

        //only prints the first five levels
        for (int depth = 0; depth < 5; depth++) {
            //number of nodes to print at a particular depth
            nodes = (int) Math.pow(2, depth);
            line = "";
            for (int j = 0; j < nodes && i < heap.length; j++) {
                if (heap[i] != null) {
                    nodeToPrint = heap[i].toString();
                    printedNodes++;
                } else {
                    nodeToPrint = "[null]";
                }
                line += " " + nodeToPrint;
                i++;
            }

            printCentered(line);
            if (i >= heap.length || printedNodes >= size) break;
        }
    }
}

