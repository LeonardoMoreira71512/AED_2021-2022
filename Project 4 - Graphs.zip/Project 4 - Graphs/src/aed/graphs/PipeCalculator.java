package aed.graphs;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

@SuppressWarnings("unused")
public class PipeCalculator {

	int n;
	float [][] well;
	float [][] costs;
	UndirectedWeightedGraph g1;
	
	public PipeCalculator(int n, float[][] well, float[][] costs) {
		this.n = n;
		this.well = well;
		this.costs = costs;
	}
	
	public UndirectedWeightedGraph createGraph(int n, float[][] well, float[][] costs) {
		var g = new UndirectedWeightedGraph(n + 1);
		
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < i; j++)
				g.addEdge(new UndirectedEdge(j, i, costs[i][j]));
		}
		
		for(int i = 0; i < n; i++) {
			//g.addEdge(new UndirectedEdge(i, n, well[i]));
		}
		return g;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
