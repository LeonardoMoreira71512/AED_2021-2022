package aed.graphs;

import java.util.LinkedList;
import java.util.Scanner;

public class DiGraph {

	private int vCount; // vertice counter
	private int eCount; // edges counter (arcos)
	private LinkedList<Integer>[] adj;

	public DiGraph(int vCount){
		this.vCount = vCount;
		this.eCount	 = 0;
		this.adj = (LinkedList<Integer>[]) new Object[vCount];
		
		//Initialise all adjacency lists
		for(int i = 0 ; i < vCount; i++)
		{
		this.adj[i] = new LinkedList<Integer>();
		}
	}

	public int vCount() {
		return this.vCount;
	}

	public int eCount() {
		return this.eCount;
	}

	public void addEdge(int v1, int v2) { // adiciona um arco entre o vertice v1 e v2
		this.adj[v1].add(v2);
		this.adj[v2].add(v1);
		this.eCount++;
	}

	public int degree(int v) { // retorna o grau do vertice ou seja o numero de arcos associados ao vertice v
								// recebido
		return this.adj[v].size();
	}

	public int maxDegree() { // retorna o maior grau do grafo
		int max = 0;
		int degree;
		for (int i = 0; i < this.vCount; i++) {
			degree = degree(i);
			if (degree > max)
				max = degree;
		}
		return max;
	}

	public Iterable<Integer> adj(int v) { // Retorna um iterador que permite iterar sobre todos os vertices adjacentes
											// ao v�rtice v recebido
		return this.adj[v];
	}

	// Faz parse de um grafo a partir de um scanner (por exemplo criado para ler um
	// ficheiro), devolvendo o Grafo lido.
	public static DiGraph parse(Scanner sc) {
		DiGraph g = new DiGraph(sc.nextInt());
		int v1, v2;
		g.eCount = sc.nextInt();

		for (int i = 0; i < g.eCount; i++) {
			v1 = sc.nextInt();
			v2 = sc.nextInt();
			g.addEdge(v1, v2);
		}
		return g;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
