package aed.graphs;
import java.util.Stack;

public class CycleDetector {

	private boolean[] visited;
	private boolean[] inCurrentPath;
	private UndirectedWeightedGraph graph;
	private boolean hasCycle;
	private Stack<UndirectedEdge> stack = new Stack<UndirectedEdge>();
	
	public CycleDetector(UndirectedWeightedGraph g) {
		this.graph = g;
		this.visited = new boolean[g.vCount()];
		this.inCurrentPath = new boolean[g.vCount()];
	}

	/*public void search() {
		int vertices = this.graph.vCount();
		this.hasCycle = false;

		// initialize array to false
		for (int i = 0; i < vertices; i++) {
			this.visited[i] = false;
			this.inCurrentPath[i] = false;
		}

		for (int i = 0; i < vertices; i++) {
			// start a new search for each vertex that has not been visited yet
			if (!this.visited[i])
				visit(i);
			if (this.hasCycle)
				return;
		}
	}*/

	private void visit(int v, int p, UndirectedEdge edge) {
		stack.push(edge);
		this.inCurrentPath[v] = true;
		this.visited[v] = true;
		int verticeadj;
		for (UndirectedEdge adj : graph.adj(v)) {
			// if a cycle was already detected we do not need to continue
			
			verticeadj = adj.other(v);
			
			if (this.hasCycle)
				return;
			else if (!this.visited[verticeadj])
				visit(verticeadj, v, adj);
			// if a vertex was already visited, we need to check if that vertex already
			// exists
			// in the current path (if so, we detected a cycle)
			else if (this.inCurrentPath[verticeadj] && verticeadj != p) {
				stack.push(adj);
				this.hasCycle = true;
				return;
			}
		}
		this.inCurrentPath[v] = false;
	}

	public boolean hasCycle() {
		return this.hasCycle;
	}
	
	public static void main(String[] args) {
		
	}

}
