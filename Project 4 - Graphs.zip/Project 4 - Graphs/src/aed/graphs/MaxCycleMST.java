package aed.graphs;

import java.util.PriorityQueue;
import java.util.Stack;

/**
* //first things frist, we should implement an algortihm that detectes a cycle
*
*@author Leonardo Moreira 71512
*@created January 17, 2022
*
*/
public class MaxCycleMST {

	private UndirectedWeightedGraph g1;
	private UndirectedWeightedGraph graph;
	private final int V;
	private boolean[] visited;
	private boolean testGet = false;
	private boolean hasCycle;
	private int endCycle;
	private Stack<UndirectedEdge> stack = new Stack<>();
	PriorityQueue<UndirectedEdge> edgeQueue = new PriorityQueue<>();
	
	
    public MaxCycleMST(UndirectedWeightedGraph g) {
		this.graph = g;
		this.V = g.vCount();
		this.visited = new boolean[V];
		
		g1 = new UndirectedWeightedGraph(V);
		for(UndirectedEdge arco: g.allEdges())
			edgeQueue.add(arco);
	}


		public void search(UndirectedWeightedGraph g) { //metodo search so vai comecar a procura, o visit e q faz a procura
			this.hasCycle = false;

			// initialize array to false
			for (int i = 0; i < V; i++) {
				this.visited[i] = false;
			}

			for (int i = 0; i < V; i++) {
				// start a new search for each vertex that has not been visited yet
				if (!this.visited[i])
					visit(i, i, null, g);
				if (this.hasCycle)
					return;
			}
		}
		
		public void searchBuild(UndirectedWeightedGraph g, int vertex) { 
			this.hasCycle = false;

			// initialize array to false
			for (int i = 0; i < V; i++) {
				this.visited[i] = false;
			}
			if (!this.visited[vertex])
				visit(vertex, -1, null, g);
			if (this.hasCycle)
				return;
		}
		
		public UndirectedEdge determineMaxInCycle(UndirectedWeightedGraph g) {
			
			if(g.eCount() == 0)
				return null;
			search(g);
			if(hasCycle) {
				UndirectedEdge maxWeightEdge = stack.pop();
				int lastV = maxWeightEdge.other(endCycle);
				while(lastV != endCycle) {
					if(maxWeightEdge.weight() < stack.peek().weight())
						maxWeightEdge  = stack.peek();
					lastV = stack.pop().other(lastV);
				}
				return maxWeightEdge;
			}
			return null;
		}
		

		private void visit(int v, int parent, UndirectedEdge edge, UndirectedWeightedGraph g) {

			if (edge != null)
				stack.push(edge);

			this.visited[v] = true;
			int nextVerticeadj;
			for (UndirectedEdge adj : graph.adj(v)) {
				nextVerticeadj = adj.other(v);
				if (this.hasCycle)
					return;
				else if (!this.visited[nextVerticeadj])
					visit(nextVerticeadj, v, adj, g);

				else if (nextVerticeadj != parent && this.visited[nextVerticeadj]) {
					stack.push(adj);
					this.hasCycle = true;
					return;
				}
			}
			if (!stack.empty() && !this.hasCycle())
				stack.pop();
		}

		public boolean hasCycle() {
			return this.hasCycle;
		}
		

		public UndirectedWeightedGraph buildMST() {
			
			if(graph.eCount() == 0)
				return null;
			UndirectedEdge arc;
			testGet = true;
			while (!edgeQueue.isEmpty()) {
				if (g1.eCount() == V - 1)
					break;
				arc = edgeQueue.remove();
				g1.addEdge(arc);
				searchBuild(g1, arc.v1());
				if (hasCycle)
					g1.removeEdge(arc);
			}
			return g1;
		}
	
		public UndirectedWeightedGraph getMST() {
			if(testGet == true)
			return g1;
			return null;
		}
	
	public static void main(String[] args) {
		UndirectedWeightedGraph g = new UndirectedWeightedGraph(3);
		
		/*g.addEdge(new UndirectedEdge(0, 1, 10));
        g.addEdge(new UndirectedEdge(1, 2, 4));
        g.addEdge(new UndirectedEdge(1, 3, 6));
        g.addEdge(new UndirectedEdge(2, 6, 8));
        g.addEdge(new UndirectedEdge(6, 8, 14));
        g.addEdge(new UndirectedEdge(8, 9, 12));
        g.addEdge(new UndirectedEdge(9, 11, 15));
        g.addEdge(new UndirectedEdge(11, 12, 15));
        g.addEdge(new UndirectedEdge(12, 7, 20));
        g.addEdge(new UndirectedEdge(7, 4, 10));
        g.addEdge(new UndirectedEdge(4, 3, 12));
        g.addEdge(new UndirectedEdge(3, 5, 30));
        g.addEdge(new UndirectedEdge(5, 10, 25));
        g.addEdge(new UndirectedEdge(2, 3, 20));*/
		
        g.addEdge(new UndirectedEdge(0, 1, 10));
		g.addEdge(new UndirectedEdge(1, 2, 15));
		g.addEdge(new UndirectedEdge(2, 0, 20));
		/*g.addEdge(new UndirectedEdge(0, 3, 30));
		g.addEdge(new UndirectedEdge(3, 4, 40));*/
		//g.addEdge(new UndirectedEdge(4, 5, 40));
		//g.addEdge(new UndirectedEdge(3, 4, 40));
        MaxCycleMST ciclo = new MaxCycleMST(g);
		
        System.out.println("---------- Original Graph ----------");
		System.out.println(g.toString());
		
		System.out.println("---------- Max Weighted Edge in the Cycle ----------");
		//System.out.println(ciclo.determineMaxInCycle(g));
		System.out.println();
		
		System.out.println("---------- Method BuildMst() ----------");
		System.out.println(ciclo.buildMST());
		
		System.out.println("---------- Get method for the MST ----------");
		System.out.println();
		System.out.println(ciclo.getMST());
		System.out.println();
		System.out.println("------ QUEUE -------");
		System.out.println(	);
		System.out.println(ciclo.edgeQueue.toString());
	
	}

}

