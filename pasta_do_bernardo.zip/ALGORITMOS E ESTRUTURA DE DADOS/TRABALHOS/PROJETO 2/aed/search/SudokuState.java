package aed.search;

import java.util.*;

import aed.collections.StackList;

public class SudokuState {

    private static final int N = 9;
    private int[][] board;

    //you can add additional parameters (including internal classes), if needed


    public SudokuState(int[][] board)
    {
        this.board = board;
        //to add additional initialization, if needed
    }

    //this method is here for testing purposes
    public int[][] getBoard()
    {
        return this.board;
    }

    public boolean isSolution() {
        
        for(int i = 0; i < N; i++) {

            for(int j = 0; j < N; j++) {
                if(board[i][j] == 0)
                    return false;
            }
        }
        return true;
    }


    public boolean isValidAction(int row, int column, int value)
    {
        //como o numero de colunas é == ao número de linhas
        //podemos usar o i para verificar as linhas e as colunas
        for(int i = 0; i < board.length; i++) {

            //Verificar se o elemento é o mesmo nas linhas ou
            //Verificar se o elemento é o mesmo nas colunas
            if(board[i][column] == value || board[row][i] == value)
                return false;
        }

        //Por fim verificar no quadrado pertencente
        int rowSquare = row - row % 3;
        int columnSquare = column - column % 3;
        
        int maxRowSquare = rowSquare + 3;
        int maxColumnSquare = columnSquare + 3;
        
        for(int i = rowSquare; i < maxRowSquare; i++) {
            for(int j = columnSquare; j < maxColumnSquare; j++) {
                
                if(board[i][j] == value)
                    return false;
            }
        }

        return true;
    }

    public SudokuState generateNextState(int row, int column, int value)
    {

        SudokuState tempState = clone();

        tempState.board[row][column] = value;

        return tempState;
    }

    public List<SudokuState> generateValidNextStates() {
        
        List<SudokuState> generatedStates = new ArrayList<SudokuState>();

        //Iterar pelo board com um duplo for
        for(int i = 0; i < N; i++) {

            for(int j = 0; j < N; j++) {

                if(board[i][j] == 0) {

                    //Verificar se o numero adicionado é valido 
                    //Caso seja gerar um novo estado e adicionar á lista
                    //Em todas as "casas" vazias testar os valores de 1 a 9
                    for(int c = 1; c <= N; c++) {
                        if(isValidAction(i, j, c))
                            generatedStates.add(generateNextState(i, j, c));
                    }

                    return generatedStates;
                }
            }
        }
        return generatedStates;
    }

    public static SudokuState backtrackingSearch(SudokuState initialState)
    {   
        //Coloca-se o initialState numa Pilha vazia
        StackList<SudokuState> boardStack = new StackList<SudokuState>();
        List<SudokuState> generatedStates = new ArrayList<SudokuState>();
        
        boardStack.push(initialState);

        while(!boardStack.isEmpty()) {
            
            initialState = boardStack.pop();

            if(initialState.isSolution()) {
                return initialState;
            }else {
                //System.out.println(initialState.toString());
                generatedStates = initialState.generateValidNextStates();
                generatedStates.forEach((i) -> boardStack.push(i));
            }

        }

        return null;
    }

    public SudokuState clone()
    {
        //you can use this method if needed
        int[][] newBoard = this.board.clone();
        //we need to be careful when copying bidimentional arrays, we need to do this:
        for(int i = 0; i < N; i++)
        {
            newBoard[i] = this.board[i].clone();
        }
        SudokuState newState = new SudokuState(newBoard);

        //copy/initialize additional parameters, if needed

        return newState;
    }

    //method useful for debugging and testing purposes
    public String toString()
    {
        String s = "";
        for(int i = 0 ; i < N ; i++)
        {
            if(i % 3 == 0)
            {
                s+= "----------------------\n";
            }
            for(int j = 0; j < N ; j++)
            {
                if(j % 3 == 0)
                {
                    s+= "|";
                }
                if(this.board[i][j] == 0)
                {
                    s+= "_ ";
                }
                else s+= this.board[i][j]+" ";
            }
            s+="|\n";
        }
        s+= "----------------------\n";
        return s;
    }
}