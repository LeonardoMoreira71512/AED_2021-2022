package aed.collections;

import java.util.Iterator;

public class QueueArray<Item> implements Iterable<Item> {

    private int size;
    private Item[] items;
    private int first;
    private int last;

    @SuppressWarnings("unchecked")
    public QueueArray(int max) {

        this.size = 0;
        this.first = 0;
        this.last = max - 1;
        this.items = (Item[]) new Object[max];
    }

    public void enqueue(Item item) {

        if (this.items.length == this.size)
            throw new OutOfMemoryError("Queue limit exceded!");
        
        this.last = (this.last + 1) % items.length;

        this.items[this.last] = item;

        this.size++;
    }

    public Item dequeue() {

        if (isEmpty())
            return null;

        Item oldItem = this.items[this.first];
        this.first = (this.first + 1) % items.length;

        this.size--;
        
        return oldItem;

    }

    public Item peek() {

        if (this.size == 0)
            return null;

        return this.items[this.first];
    }

    public boolean isEmpty() {
        return this.size == 0;
    }

    public int size() {
        return this.size;
    }

    public QueueArray<Item> shallowCopy() {

        QueueArray<Item> copiedQueue = new QueueArray<Item>(this.items.length);
        copiedQueue.size = this.size;
        copiedQueue.first = this.first;
        copiedQueue.last = this.last;

        for (int i = 0; i < this.items.length; i++) {

            copiedQueue.items[i] = this.items[i];
        }

        return copiedQueue;
    }

    @Override
    public Iterator<Item> iterator() {
        return new QueueArrayIterator();
    }

    //inner class for iterator
    private class QueueArrayIterator implements Iterator<Item> {

        private int iterator;
        private int itFirst;

        QueueArrayIterator() {

            iterator = size-1;
            itFirst = first;
        }

        public boolean hasNext() {
            return iterator >= 0;
        }

        public Item next() {

            int tempFirst = itFirst;
            itFirst = (itFirst + 1) % items.length;
            
            while(items[itFirst] == null) {
                itFirst = (itFirst + 1) % items.length;
            }

            iterator--;

            return items[tempFirst];
        }

        public void remove() {
            throw new UnsupportedOperationException("This Iterator doesn't support removal!");
        }
    }
}