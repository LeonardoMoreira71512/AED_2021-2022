package aed.collections;

import java.util.Iterator;

public class StackList<Item> implements Iterable<Item> {

    // A class node vai conter um generico e vai conter o node do proximo elemento
    private class Node {
        private Item item;
        private Node next;
    }

    private Node first;
    private int size;

    public StackList() {
        first = null;
        size = 0;
    }

    public void push(Item item) {

        // Guardar o node atual numa variavel
        Node oldFirst = first;

        // Com isto definimos o "first" para o nosso novo primeiro elemento do stack
        // Fazendo assim de facto um "Push"! Ficando agora first -> oldFirst
        // Assim cada Node (na StackList) tendo conhecimento do próximo
        first = new Node();
        first.item = item;
        first.next = oldFirst;

        size++;
    }

    public Item pop() {

        if(isEmpty())
            return null;

        Item newestItem = first.item;

        // O primeiro elemento agora será == ao próximo!
        first = first.next;
        size--;

        // Retornamos o item que tinhamos armazenado
        return newestItem;
    }

    public Item peek() {
        if(isEmpty())
            return null;
        return first.item;
    }

    public boolean isEmpty() {
        return first == null;
    }

    public int size() {
        return size;
    }

    public StackList<Item> shallowCopy() {

        StackList<Item> newStack = new StackList<Item>();

        newStack.first = new Node();
        Node oldNode = first;
        Node newNode = newStack.first;

        for (int i = 0; i < size; i++) {

            newNode.item = oldNode.item;

            if (oldNode.next != null) {

                newNode.next = new Node();

                newNode = newNode.next;
                oldNode = oldNode.next;
            }
        }

        return newStack;
    }

    @Override
    public Iterator<Item> iterator() {
        
        return new StackListIterator();
    }

    //inner class for iterator
    private class StackListIterator implements Iterator<Item> {

        Node iterator;

        StackListIterator() {

            iterator = first;
        }

        public boolean hasNext() {
            return iterator != null;
        }

        public Item next() {
            Item result = iterator.item;
            iterator = iterator.next;
            return result;
        }

        public void remove() {
            throw new UnsupportedOperationException("This Iterator doesn't support removal!");
        }
    }
}
