import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Utils {
	
	static List<Jogador> leJogadoresFicheiro(String Ficheiro) {
		
		List<Jogador> jogadores = new ArrayList<Jogador>();
		
		try {

			File allPlayers = new File(Ficheiro);
			Scanner readPlayers = new Scanner(allPlayers);

			while(readPlayers.hasNextLine()) {
			
				Jogador newPlayer = Jogador.parseJogador(readPlayers.nextLine());
				jogadores.add(newPlayer);
			
			}
		readPlayers.close();
		}catch(FileNotFoundException e){

			System.out.println("Ficheiro nao encontrado!");
			e.printStackTrace();
			
		}
		
		
		return jogadores;
	}
	
	static void ordenaJogadores(List<Jogador> jogadores) {

		Jogador j1;
		Jogador j2;

		for(int i = 0; i < jogadores.size() - 1; i++) {
			int j = i + 1;

			j1 = jogadores.get(i);
			j2 = jogadores.get(j);
			if(j1.compareTo(j2) >= 1) {
				Collections.swap(jogadores, i, j);
				i = -1;
				//i = -1 pois depois o i irá somar outravez!
			}
		}
		
	}

	static void imprimeJogadores(List<Jogador> jogadores) {

		for (Jogador jogador : jogadores) {
			System.out.println(jogador.toString());
		}
	}

	static List<Jogador> filtraPorClube(List<Jogador>jogadores, String clube) {
		
		List<Jogador> jogadoresFiltro = new ArrayList<Jogador>();

		for (Jogador jogador : jogadores) 
		{
			if(clube.equals(jogador.getClube()))
				jogadoresFiltro.add(jogador);
		}
		return jogadoresFiltro;
	}

	static List<Jogador> filtraPorIdadeMaxima(List<Jogador> jogadores, int idadeMaxima) throws UnsupportedOperationException {

		throw new UnsupportedOperationException("Quebra de Abstracao de dados!");

		//return jogadoresFiltro;
	}

	static int totalIntern(List<Jogador> jogadores) {

		int total = 0;

		for (Jogador jogador : jogadores) {
			total += jogador.getInternacionalizacoes();
		}

		return total;
	}

	//Verificar se o clube já está contido na lista dos clubes
	//Se não tiver Adicionar, Se estiver, somar apenas as internacionalizacoes
	private static void verificarClube(List<Clube> clubes, Jogador jogadores) {

		for(int i = 0; i < clubes.size(); i++) {

			if(clubes.get(i).getNome().equals(jogadores.getClube())) {

				int c = clubes.get(i).getInternacionalizacoes() + jogadores.getInternacionalizacoes();
				clubes.get(i).setInternacionalizacoes(c);
				return;

			}
		}
		//Caso o clube não exita, criamo-lo
		Clube novoClube = 
		new Clube(jogadores.getClube(), jogadores.getInternacionalizacoes());

		clubes.add(novoClube);

	} //pum chtcht ta pum pum pum piuuu

	//criar a lista dos nomes dos clubes e fazer a verificação
	static List<Clube> calculaListaClubes(List<Jogador> jogadores) {

		List<Clube> clubesTotais = new ArrayList<Clube>();

		for (Jogador jogador : jogadores) {

			verificarClube(clubesTotais, jogador);
		}

		return clubesTotais;
	}

	static List<String> listaNomesClubes(List<Jogador> jogadores) {

		List<String> clubesTotais = new ArrayList<String>();

		for (Jogador jogador : jogadores) {
			
			if(!clubesTotais.contains(jogador.getClube())) {

				clubesTotais.add(jogador.getClube());
			}
		}

		return clubesTotais;
	}

	static void ordenaClubes(List<Clube> clubes) {

		Clube c1;
		Clube c2;

		for(int i = 0; i < clubes.size() - 1; i++) {
			int j = i + 1;

			c1 = clubes.get(i);
			c2 = clubes.get(j);
			if(c1.compareTo(c2) >= 1) {
				Collections.swap(clubes, i, j);
				i = -1;
				//i = -1 pois depois o i irá somar outravez!
			}
		}

	}

	static void imprimeClubes(List<Clube> clubes) {

		for (Clube clube : clubes) {
			System.out.println(clube.toString());
		}
	}
	

}
