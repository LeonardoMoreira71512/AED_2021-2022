
public class Clube {
	
	protected String nomeClube;
	protected int internacionalizacoes;
	
	//---------------------//
	
	public Clube(String nome, int internacional) {
		//Objeto
		nomeClube = nome;
		internacionalizacoes = internacional;
	}
	
	//Retorna o Nome do clube
	public String getNome() {
		return nomeClube;
	}
	
	//Retorna o valor de internacionalizacoes totais do clube
	public int getInternacionalizacoes() {
		return internacionalizacoes;
	}
	
	//Modifica o valor das internacionalizacoes para o valor dado
	public int setInternacionalizacoes(int internacional) {
		internacionalizacoes = internacional;
		return internacionalizacoes;
	}
	
	//Cria uma string com o nome e internacionalizacoes do clube
	public String toString() {
		String information = nomeClube + " " + internacionalizacoes;
		return information;
	}
	
	//Se for um numero maior que 0 o clube (clube.compareTo(ex)) tem que se situar abaixo
	public int compareTo(Clube c2) {
		int total = c2.internacionalizacoes - internacionalizacoes;
		
		if(total != 0) {
			return total;
		}
		
		total = nomeClube.compareTo(c2.nomeClube);
		
		return total;
	}
	

}
