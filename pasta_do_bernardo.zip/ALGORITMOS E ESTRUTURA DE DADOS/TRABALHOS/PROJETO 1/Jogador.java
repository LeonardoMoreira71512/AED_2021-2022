
public class Jogador {
	
	protected String nome;
	protected String posicao;
	protected int anoNascimento;
	protected String clube;
	protected int golos;
	protected int internacionalizacoes;
	
	public Jogador(String nomeJogador, String position, int anoDeNascimento, String club,
			int goals, int internacional) {
		
		nome = nomeJogador;
		posicao = position;
		anoNascimento = anoDeNascimento;
		clube = club;
		golos = goals;
		internacionalizacoes = internacional;
	}
	
	public static Jogador parseJogador(String texto) {
		String[] Separated = texto.split(" ");
		
		Jogador jogador = new Jogador(Separated[1], Separated[2], 
				Integer.parseInt(Separated[4]), Separated[5], 
				Integer.parseInt(Separated[3]), Integer.parseInt(Separated[0]));
		
		return jogador;
	}
	
	// Metodos Simples para cada categoria //
	
	public String getNome( ) {
		return nome;
	}
	
	public String getPosicao( ) {
		return posicao;
	}
	
	public String getClube( ) {
		return clube;
	}
	
	public int getGolos() {
		return golos;
	}
	
	public int getInternacionalizacoes() {
		return internacionalizacoes;
	}
	
	public String toString( ) {
		String informacao = nome + " " + anoNascimento + " " + posicao + " " + 
				clube + " " +  internacionalizacoes + " " + golos;
		return informacao;
	}
	
	/////////////////////////////////
	
	public int compareTo(Jogador j2) {
		int total = 0;
		
		String[] positionOrder = {"Guarda_Redes", "Medio", "Defesa", "Avancado"};
		
		//Verificar posicao
		for(String el : positionOrder) {
			
			if(posicao.equals(el) && !posicao.equals(j2.posicao)) {
				
				total = -1;
				return total;
				
			}else if(j2.posicao.equals(el) && !posicao.equals(j2.posicao)) {
				
				total = 1;
				return total;
			}
			
		}
		
		//Contagem com golos
		total = j2.golos - golos;
		
		if(total != 0)
			return total;
		//Contagem por internacionalizacoes
		total = j2.internacionalizacoes - internacionalizacoes;
		
		if(total != 0)
			return total;
		//Ordenacao de nome
		total = nome.compareTo(j2.nome);
		
		return total;
	}
	
	
	
	

}
