import java.util.List;

public class Main {
	
public static void main(String[] args) {
		
		/*Clube sporting = new Clube("Sporting", 15);
		//Clube benfica = new Clube("Benfica", 10);
		
		sporting.setInternacionalizacoes(45);
		System.out.println(sporting.toString());*/
	
		/*Jogador deco = Jogador.parseJogador("75 Deco Medio 5 1977 PORTO");
		Jogador pauloSousa = Jogador.parseJogador("51 Paulo_Sousa Medio 0 1970 SPORTING");
		Jogador pepe = Jogador.parseJogador("68 Pepe Defesa 3 1983 REAL_MADRID");
		Jogador ukra = Jogador.parseJogador("1 Ukra Avancado 0 1988 RIO_AVE");
		Jogador bernardoSilva = Jogador.parseJogador("5 Bernardo_Silva Avancado 0 1994 MONACO");
		Jogador saPinto = Jogador.parseJogador("45 Sa_Pinto Avancado 10 1972 SPORTING");
		Jogador ricardoQuaresma = Jogador.parseJogador("45 Ricardo_Quaresma Avancado 4 1983 BESIKTAS");
		System.out.println(deco.getClube());
		System.out.println(deco.compareTo(pepe));*/
	
		List<Jogador> jogadores = Utils.leJogadoresFicheiro("futebolistas.txt");
		List<Clube> clubes = Utils.calculaListaClubes(jogadores);

		Utils.ordenaJogadores(jogadores);
		Utils.imprimeJogadores(jogadores);

		//System.out.println(clubes);
	}

}
