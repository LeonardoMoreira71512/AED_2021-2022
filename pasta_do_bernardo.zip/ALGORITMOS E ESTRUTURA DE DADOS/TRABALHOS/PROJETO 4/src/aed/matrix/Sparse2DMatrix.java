package aed.matrix;

import java.util.Random;
import java.util.Vector;

import aed.tables.OpenAddressingHashTable;

public class Sparse2DMatrix {
  
  private class Vector2D {
    
    private int x;
    private int y;
    private int R = 31;

    private Vector2D(int x, int y) {
      this.x = x;
      this.y = y;
    }

    @Override
    public boolean equals(Object obj) {
      // If the object is compared with itself then return true   
      if (obj == this) { 
          return true; 
      } 

      // Check if o is an instance of Complex or not 
      //  "null instanceof [type]" also returns false 
      if (!(obj instanceof Vector2D)) { 
          return false; 
      } 
        
      // typecast o to Complex so that we can compare data members  
      Vector2D c = (Vector2D) obj; 
        
      // Compare the data members and return accordingly  
      return Integer.compare(x, c.x) == 0 && Integer.compare(y, c.y) == 0; 
    }

    @Override
    public int hashCode() {
      int hash = 17;
      hash = R*hash + ((Integer) x).hashCode();
      hash = R*hash + ((Integer) y).hashCode();
      return hash;
    }

  }

  private int lines; 
  private int columns; 
  OpenAddressingHashTable<Vector2D, Float> sparseMatrix;
    
  public Sparse2DMatrix(int lines, int columns)
  {
    this.lines = lines;
    this.columns = columns;
    sparseMatrix = new OpenAddressingHashTable<Vector2D,Float>();

  }

  public int getNumberNonZero() {
    return sparseMatrix.size();
  }

  public void put(int line, int column, float value)
  {
    Vector2D tempVector = new Vector2D(line, column);
    //If the value is 0, we want to interpretate it as being a null value
    //on the hash tables!
    //So we either delete the value in the hash table or we don't put it
    if(value == 0) {
      sparseMatrix.put(tempVector, null);
      return;
    }
    sparseMatrix.put(tempVector, value);

  }

  public float get(int line, int column)
  {
    Vector2D tempVector = new Vector2D(line, column);
    return sparseMatrix.get(tempVector) == null ? 0f : sparseMatrix.get(tempVector);
  }

  public Sparse2DMatrix scalar(float scalar)
  {
    Sparse2DMatrix tempMatrix = new Sparse2DMatrix(this.lines, this.columns);

      for(Vector2D el : this.sparseMatrix.keys()) {
        
        float currentValue = this.sparseMatrix.get(el);

        tempMatrix.put(el.x, el.y, currentValue * scalar);
        
      }

    return tempMatrix;
    
  }

  public Sparse2DMatrix sum(Sparse2DMatrix that)
  {
    if(that.lines != this.lines || that.columns != this.columns)
      throw new IllegalArgumentException();

    Sparse2DMatrix tempMatrix = new Sparse2DMatrix(this.lines, this.columns);

    //We create a copy of this matrice
    for(Vector2D el : this.sparseMatrix.keys()) {
        
      float currentValue = this.sparseMatrix.get(el);

      tempMatrix.put(el.x, el.y, currentValue);
      
    }

    //And then we sum the values
    for(Vector2D el : that.sparseMatrix.keys()) {
      
      //We get the value of the other matrice
      float thatValue = that.sparseMatrix.get(el);

      //If we try and get a value from key that doesn't exist we sum with 0!
      //If a key exists we sum it's value instead
      float currentValue = tempMatrix.sparseMatrix.get(el) == null ? 0f : tempMatrix.sparseMatrix.get(el);

      tempMatrix.put(el.x, el.y, thatValue + currentValue);
      
    }

    return tempMatrix;

  }

  public Sparse2DMatrix multiply(Sparse2DMatrix that)
  {
    if(this.columns != that.lines)
      throw new IllegalArgumentException();

    // [ Matrice Property ]
    //"This" number of lines but "that" number of columns!
    Sparse2DMatrix tempMatrix = new Sparse2DMatrix(this.lines, that.columns);

    for(Vector2D thisEl : this.sparseMatrix.keys()) { //Values not 0 from "this"

      for (Vector2D thatEl : that.sparseMatrix.keys()) { //Values not 0 from "that"

        if(thisEl.y == thatEl.x) {

          float currentValue = this.sparseMatrix.get(thisEl) * that.sparseMatrix.get(thatEl);

          Vector2D tempVector = new Vector2D(thisEl.x, thatEl.y);
          //Attention: This value can be null so we need to transform it to a 0
          float tempValue = tempMatrix.sparseMatrix.get(tempVector) == null ? 0f : tempMatrix.sparseMatrix.get(tempVector);
          
          tempMatrix.put(tempVector.x, tempVector.y, currentValue + tempValue);
        }
      }    

    }
    return tempMatrix;
  }
    
  public float[] getNonZeroElements() {
    
    float[] nonZeroEl = new float[sparseMatrix.size()];
    int i = 0;
    for(Vector2D el : this.sparseMatrix.keys()) {
        
      float currentValue = this.sparseMatrix.get(el);

      nonZeroEl[i++] = currentValue;
      
    }

    return nonZeroEl;
  }

  public float[][] getNonSparseMatrix()
  {
    float[][] nonSparseMatrix = new float[this.lines][this.columns];

    for(Vector2D el : this.sparseMatrix.keys()) {
        
      float currentValue = this.sparseMatrix.get(el);

      nonSparseMatrix[el.x][el.y] = currentValue;
      
    }

    return nonSparseMatrix;
  }


  private static double calculateTime(String type, int lines1, int columns1, int lines2, int columns2, float nonZeros) {
      long startTime = 0;
      double totalTime = 0;

        Sparse2DMatrix test = generateExample(lines1, columns1, nonZeros);
        Sparse2DMatrix test2 = generateExample(lines2, columns2, nonZeros);

        switch(type) {
          case "normal":
            float[][] nonSparsetest = test.getNonSparseMatrix();
            float[][] nonSparsetest2 = test2.getNonSparseMatrix();
            startTime = System.currentTimeMillis();
            test.multiply(nonSparsetest, nonSparsetest2, test.lines, test.columns, test2.columns);
            totalTime += System.currentTimeMillis() - startTime;
            break;
          case "sparce":
            startTime = System.currentTimeMillis();
            test.multiply(test2);
            totalTime += System.currentTimeMillis() - startTime;
            break;
      }

      return totalTime;
  }

  private float[][] multiply(float[][] matrice1, float[][] matrice2, int r1, int c1, int c2) {

    float[][] product = new float[r1][c2];
    for(int i = 0; i < r1; i++) {
        for (int j = 0; j < c2; j++) {
            for (int k = 0; k < c1; k++) {
                product[i][j] += matrice1[i][k] * matrice2[k][j];
            }
        }
    }

    return product;
  }

  private static Sparse2DMatrix generateExample(int lines, int columns, float nonZeros) {
      int i = 0;
      Sparse2DMatrix examples = new Sparse2DMatrix(lines, columns);

      int total = lines * columns;
      float nonZeroQuantity = 0;
      Random r = new Random();
      while(nonZeroQuantity < (float) nonZeros/100) {
          int randomLine = r.nextInt(lines);
          int randomColumn = r.nextInt(columns);
          examples.put(randomLine, randomColumn, i);
          nonZeroQuantity = (float) examples.getNumberNonZero()/total;
          i++;
      }
      System.out.println("Non Zeros%: " + (float) nonZeroQuantity * 100);
      return examples;
  }

  public static void main(String[] args) {

    String type = "normal";
    System.out.print("How many time in a " + type + " matrice");
    System.out.println("Time: " + calculateTime(type, 100, 100, 100, 100, 5) + " ms");

    //================ [ 1000 x 1000 multiply with 1000 x 1] ==================\\
    // [Percentage of non zeros] ||   1.0%   ||   5.0%   ||   30%   ||   80%   \\
    //   normal matrice times    ||  12.000  ||  11.500  ||  11.000 ||  13.000 \\
    //   sparce matrice times    ||  11.000  ||  58.000  ||  570.00 ||  4791.0 \\
    //================= [ 100 x 100 multiply with 100 x 100] ==================\\
    // [Percentage of non zeros] ||   1.0%   ||   5.0%   ||   30%   ||   80%   \\
    //   normal matrice times    ||  11.000  ||  13.000  ||  12.000 ||  11.000 \\
    //   sparce matrice times    ||  4.0000  ||  15.000  ||  119.00 ||  481.00 \\   
    //=========================================================================\\

    //The normal matrice will not depend on the percentage of non zeros, since it multiples
    //all values either way!
    //This matrice will only depend on the size of the matrices, the bigger the more time it will take
    //On the other hand, sparce matrice is slower depending on the percentage of non zeros
    //the size of the array doesn't matter that much unless the array is full 
  }
}