package aed.tables;

import java.util.Iterator;
import java.util.Random;

public class OpenAddressingHashTable<Key,Value> {


    private static int[] primes = {
            17, 37, 79, 163, 331,
            673, 1361, 2729, 5471, 10949,
            21911, 43853, 87719, 175447, 350899,
            701819, 1403641, 2807303, 5614657,
            11229331, 22458671, 44917381, 89834777, 179669557
    };

    private int m;
    private int p;
    private int primeIndex;
    private int size;
    private float loadFactor;
    private int deletedNumbers;
    
    private Key[] keys;
    private Value[] values;


    @SuppressWarnings("unchecked")
    private OpenAddressingHashTable(int primeIndex) {
        this.primeIndex = primeIndex;
        this.m = this.primes[primeIndex];
        this.p = this.primes[primeIndex-1];
        this.deletedNumbers = 0;
        this.size = 0; 
        this.loadFactor = 0;
        this.keys = (Key[]) new Object[this.m];
        this.values = (Value[]) new Object[this.m];
    }

    public OpenAddressingHashTable()
    {
        this(1);
    }

    private int hash(Key k)
    {
        return (k.hashCode() & 0x7fffffff) % this.m;
    }
    

    public int size()
    {
        return size;
    }

    public int getCapacity()
    {
        return m;
    }

    public float getLoadFactor()
    {
        return loadFactor;
    }

    public int getDeletedNotRemoved()
    {
        return deletedNumbers;
    }

    public boolean containsKey(Key k)
    {
        return get(k) != null;
    }

    public Value get(Key k)
    {
        int j = p - (hash(k) % this.p);

        //Here we need to verify by key!
        //Because the key that we want to check can exist after
        //The key that we're currently check
        //So if it is an erased key, we still want to check
        //And if we try to get an erased key it will return null
		for(int i = hash(k); this.keys[i] != null; i = (i+j) % this.m) {
            //key was found, return its value
            if(this.keys[i].equals(k))
                return this.values[i];
        }

        //if it exits the for loop there's no key
        return null;
    }

    private void resize(int primeIndex) {
        //if invalid size do not resize;
        if(primeIndex < 0 || primeIndex >= primes.length) 
            return;
        this.primeIndex = primeIndex;
        OpenAddressingHashTable<Key,Value> aux = new OpenAddressingHashTable<Key,Value>(this.primeIndex);
        //place all existing keys in new table
        for(int i = 0; i < this.m; i++) {
            //Verify if VALUES are not null since we don't want to insert erased values
            if(values[i] != null) 
                aux.put(keys[i],values[i]);
        }
        this.keys = aux.keys;
        this.values = aux.values;
        this.m = aux.m;
        this.p = aux.p;
        this.loadFactor = (float) this.size/this.m;
        this.deletedNumbers = 0;
}

    public void put(Key k, Value v)
    {

        //If theres a case where v is null, return and try to delete
        if(v == null) {
            delete(k);
            return;
        }

		if(this.loadFactor >= 0.5f)
            resize(this.primeIndex+1);

        int i = hash(k) % this.m;
        int j = p - (hash(k) % this.p);

        //We need to verify the VALUE, because we can
        //insert a key in a null key or erased key
        for(; this.keys[i] != null; i = (i + j) % this.m) {
            //key was found, update its value
            if(this.keys[i].equals(k)) {
                if(values[i] == null){
                    deletedNumbers--;
                    size++;
                    this.loadFactor = (float) this.size/this.m;
                }
                this.values[i] = v;
                return;
            }
        }

        //we've found the right insertion position, insert
        this.keys[i] = k;
        this.values[i] = v;
        this.size++;
        this.loadFactor = (float) this.size/this.m;

    }

    public void delete(Key k)
    {
        int i = hash(k) % this.m;
        int j = p - (hash(k) % this.p);

        while(true) {
            //no key to delete, return
            if(this.keys[i] == null) 
                return;
            //if key was found and it's not already deleted, exit the loop
            if(this.keys[i].equals(k) && this.values[i] != null) 
                break;
            i = (i+j)%this.m;
        }

        //delete the key and value
        this.values[i] = null;
        this.size--;
        this.deletedNumbers++;
        float deleteFactor = (float) this.deletedNumbers/this.m;

        this.loadFactor = (float) this.size/this.m;

        if(this.loadFactor < 0.125f)
            resize(this.primeIndex-1);
        else if(deleteFactor >= 0.2f)
            resize(this.primeIndex);

    }


    private Value linearGet(Key k)
    {
		for(int i = hash(k); this.keys[i] != null; i = (i+1) % this.m) {
            //key was found, return its value
            if(this.keys[i].equals(k))
                return this.values[i];
        }

        //if it exits the for loop there's no key
        return null;
    }

    private void linearResize(int primeIndex) {
        //if invalid size do not resize;
        if(primeIndex < 0 || primeIndex >= primes.length) 
            return;
        this.primeIndex = primeIndex;
        OpenAddressingHashTable<Key,Value> aux = new OpenAddressingHashTable<Key,Value>(this.primeIndex);
        //place all existing keys in new table
        for(int i = 0; i < this.m; i++) {
            if(keys[i] != null) 
                aux.put(keys[i],values[i]);
        }
        this.keys = aux.keys;
        this.values = aux.values;
        this.m = aux.m;
        this.loadFactor = (float) this.size/this.m;
}

    private void linearPut(Key k, Value v) {

		if(this.loadFactor >= 0.5f)
            linearResize(this.primeIndex+1);

        int i = hash(k) % this.m;
        for(; this.keys[i] != null; i = (i + 1) % this.m) {
            //key was found, update its value
            if(this.keys[i].equals(k)) {
                this.values[i] = v;
                return;
            }
        }
        //we've found the right insertion position, insert
        this.keys[i] = k;
        this.values[i] = v;
        this.size++;
        this.loadFactor = (float) this.size/this.m;

    }

    private void linearDelete(Key k)
    {
		int i = hash(k);
        while(true) {
            //no key to delete, return
            if(this.keys[i] == null) 
                return;
            //if key was found, exit the loop
            if(this.keys[i].equals(k)) 
                break;
            i = (i+1)%this.m;
        }

        //delete the key and value
        this.keys[i] = null;
        this.values[i] = null;
        this.size--;
        //we need to reenter any subsequent keys
        i = (i+1)%this.m;

        while(this.keys[i] != null) {
            Key auxKey = this.keys[i];
            Value auxValue = this.values[i];
            //remove from previous position
            this.keys[i] = null;
            this.values[i] = null;
            //temporarily reduce size,
            //next put will increment it
            this.size--;
            //add the key and value again
            this.put(auxKey,auxValue);
            i = (i+1)%this.m;
        }

        this.loadFactor = this.size/this.m;

        if(this.loadFactor < 0.125f)
            linearResize(this.primeIndex-1);

    }

    public Iterable<Key> keys() {
        return new KeysIterable();
    }

    @SuppressWarnings("unchecked")
    private static double calculateTime(int n, float factorQuantity) {
        double trials = 75;
        double totalTime = 0;

        for(int i = 0; i < trials; i++) {
            OpenAddressingHashTable test = generateExample(factorQuantity);
            long startTime = System.currentTimeMillis();
            for(int j = 0; j < n; j++) {
                test.get(test.m);
            }
            totalTime += System.currentTimeMillis() - startTime;
        }

        return totalTime/trials;
    }

    @SuppressWarnings("unchecked")
    private static OpenAddressingHashTable generateExample(float factorQuantity) {
        int i = 0;
        OpenAddressingHashTable examples = new OpenAddressingHashTable<>();

        while(examples.getLoadFactor() < factorQuantity) {
            examples.put(i, i);
            i++;
        }
        System.out.println("Load Factor: " + examples.getLoadFactor());
        return examples;
    }

    @SuppressWarnings("unchecked")
    public static void main(String[] args) {


        //Small tests
        OpenAddressingHashTable test = new OpenAddressingHashTable<>();
        test.put(3, 5);
        test.put(2, 5);
        test.put(1, 5);
        test.put(4, 5);
        test.put(850, 5);
        test.put(44, 5);
        test.put(22, 5);
        test.put(11, 5);
        test.delete(22);
        test.put(22, 21);

        /*Iterable it = test.keys();
        for (Object el : it) {
            System.out.println(el);
        }*/



        System.out.print("time: " + calculateTime(100, 0.4f) + " ms");
        System.out.print("\nFinished");

        //Tests made for get
        //A Hash Table is created with a maximum capacity of 701 819 elements
        //The calculate time function creates an Hash Table with that number of elements
        //And then tries to get a non existing value 100 times!
        //That process repeats 75 times, with this we can expect LONG times, expeccially
        //On linear probing since we are basiccly testing this huge number of elements 7500 times!
        //We will have an enormous number of clusters, and that will make the linear probing take
        //a long time, in theory double hashing will be better
        
        //We use different values for the LoadFactor to see how it impacts
        //We start with 0.2 as a base value, and then we oscillate between
        //An Addressing Hash Table is created with the Load Factor >= number we choose
        //That number being between 0.2 and 0.5!
        //And then we do the tests with the get

        //=========================================================//
        //-------------- [Hashing vs Double Hashing] --------------//
        //------------------- [Getting Elements] ------------------//
        //=========================================================//
        //                 ||             ||                       // times hash
        //   Load Factor   ||   Hashing   ||    Double Hashing     // ===========================
        //                 ||             ||                       // times doubleHash
        //-----------------||-------------||-----------------------//
        //                 ||             ||                       // 52.830 52.667 52.560 52.960
        //      0.2000     ||   52.754    ||        0.0067         // =========================== 
        //                 ||             ||                       // 0.0133 0.0000 0.0133 0.0000
        //-----------------||-------------||-----------------------//
        //                 ||             ||                       // 66.840 65.947 66.600 66.760
        //      0.2500     ||   66.537    ||        0.0700         // ===========================
        //                 ||             ||                       // 0.0000 0.0000 0.0267 0.0133
        //-----------------||-------------||-----------------------//
        //                 ||             ||                       // 82.600 81.533 81.373 82.493
        //      0.3000     ||   81.999    ||        0.0033         // ===========================
        //                 ||             ||                       // 0.0000 0.0133 0.0000 0.0000
        //-----------------||-------------||-----------------------//
        //                 ||             ||                       // 114.19 113.55 113.16 113.72
        //      0.4000     ||   113.66    ||        0.0143         // ===========================
        //                 ||             ||                       // 0.0040 0.0133 0.0133 0.0267
        //-----------------||-------------||-----------------------//
        //                 ||             ||                       // 136.00 134.39 137.89 136.33
        //      0.4801     ||   136.15    ||        0.0120         // ===========================
        //                 ||             ||                       // 0.0133 0.0133 0.0133 0.0040
        //-----------------||-------------||-----------------------//

        //Has we can see the double hashing method is EXPONENTIALLY Better
        //Its true that the way that the adressing tables were build were
        //in favor of the double hashing, the hashtables add number from i to a value that
        //satisfected the loadfactor (1,2,3,4,5,6, etc...) with linear probing if we didn't find a
        //value we had to search through ALL the array until we found the desired value, or until we
        //reach a null value, and with double hashing it's way more easy, because we follow a pattern
        //that reaches the value in a faster way, not iteration the WHOLE array, only some values!

    }

    //inner class for iterator
    private class KeysIterable implements Iterator<Key>, Iterable<Key> {

        int i;

        KeysIterable() {
            i = 0;
        }
    
        public boolean hasNext() {
            while(i < m && values[i] == null)
                i++;
            return i < m;
        }
    
        public Key next() {
            return keys[i++];
        }
    
        public void remove() {
            throw new UnsupportedOperationException("This Iterator doesn't support removal!");
        }

        @Override
        public Iterator<Key> iterator() {
            return new KeysIterable();
        }
    }
}