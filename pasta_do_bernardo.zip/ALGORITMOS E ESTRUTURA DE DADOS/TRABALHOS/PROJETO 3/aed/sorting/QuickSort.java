package aed.sorting;

import java.util.Random;

public class QuickSort extends Sort{

    public static void sort(Comparable[] a)
    {
        Random random = new Random();
        sort(a, random, 0, a.length-1);
    }

    private static void sort(Comparable[] a, Random random, int low, int high) {
        
        if(high <= low)
            return;

        int j = partition(a, random, low, high);
        sort(a, random, low, j-1);
        sort(a, random, j+1, high);
    }

    private static int partition(Comparable[] a, Random random, int low, int high) {
        //Verificar a esquerda e a direita, sendo low o valor da esquerda
        // E high o valor da direita
        int i = low;
        int j = high + 1;
        int rnd = random.nextInt(high - low) + low; //Gerar um valor aleatorio entre high e low
        Comparable v = a[rnd];
        exchange(a, rnd, low);

        while(true) {

            while(less(a[++i], v)) 
                if(i == high)
                    break;

            while(less(v, a[--j]))
                if(j == low)
                    break;

            if(j <= i)
                break;

            exchange(a, i, j);
        }
        exchange(a, low, j);

        return j;
    }
	
    public static void medianSort(Comparable[] a)
    {
        medianSort(a, 0, a.length/2, a.length - 1);
    }

    private static void medianSort(Comparable[] a, int low, int mid, int high) {

        int cutOff = 15;
        int pivot;

        if(high <= low)
            return;

        //Utilizacao do insertionSOrt 
        if(high - low < cutOff) {
            insertionSort(a, low, high);
            return;
        }

        //low needs to be where the lower value is
        //and high the highest 
        if(less(a[mid], a[low]))
            exchange(a, mid, low);

        if(less(a[high], a[low]))
            exchange(a, high, low);

        if(less(a[high], a[mid]))
            exchange(a, high, mid);

        // V
        if(mid != low) {
            exchange(a, mid, low+1);
            pivot = low + 1;
        }else {
            pivot = low;
        }
            
        int j = medianPartition(a, pivot, low, high);
        int newLow = j+1;
        int newHigh = j-1;
        medianSort(a, low, (newHigh + low)/2, newHigh);
        medianSort(a, newLow, (high + newLow)/2, high);

    }


    private static int medianPartition(Comparable a[], int pivot,int low, int high) {
        
        //It is called pivot beacause it can be low + 1 (where mid is located)
        //Or it can bem just low (when mid is located in the same place as low)
        int i = pivot;
        int j = high;
        Comparable v = a[pivot];

        while(true) {

            //Scan right
            while(less(a[++i], v)) ;

            //Scan left
            while(less(v, a[--j])) ;

            if(j <= i)
                break;

            exchange(a, i, j);
        }

        //Exchange j with the value of v
        exchange(a, pivot, j);

        return j;
    }

    public static Comparable quickSelect(Comparable[] a, int n)
    {
        Random random = new Random();
        Comparable result = quickSelect(a, random, n, 0, a.length-1);
		return result;
    }

    private static Comparable quickSelect(Comparable[] a, Random random, int n, int low, int high) {

        if(high <= low)
            return a[n];
        
        int j = partition(a, random, low, high);

        if(j == n)
            return a[j];
        else if(n < j)
            return quickSelect(a, random, n, low, j-1);
        else
            return quickSelect(a, random, n, j+1, high);
        
    }

    private static double calculateTime(int n, String example) {
        int trials = 75;
        double totalTime = 0;

        for(int i = 0; i < trials; i++) {
            Comparable[] exampleArray;

            switch(example) {

                case "random":
                    exampleArray = generateExample(n);
                    break;

                case "inverse":
                    exampleArray = generateInverseExample(n);
                    break;

                case "sorted":
                    exampleArray = generateSortedExample(n);
                    break;
                case "partial":
                    exampleArray = generatePartialExample(n);
                    break;
                default:
                    exampleArray = generateExample(n);
            }

            long startTime = System.currentTimeMillis();
            sort(exampleArray);
            totalTime += System.currentTimeMillis() - startTime;
        }

        return totalTime/trials;
    }

    private static Comparable[] generateExample(int n) {
        Random r = new Random();
        Comparable[] examples = new Comparable[n];

        for(int i = 0; i < n; i++) {
            //Make an int array for test puposes//
            examples[i] = r.nextInt();
        }

        return examples;
    }

    private static Comparable[] generateInverseExample(int n) {
        Comparable[] examples = new Comparable[n];
        int j = n;

        for(int i = 0; i < n; i++) {
            //Make an int array for test puposes//
            examples[i] = j--;
        }

        return examples;
    }

    private static Comparable[] generateSortedExample(int n) {
        Comparable[] examples = new Comparable[n];

        for(int i = 0; i < n; i++) {
            //Make an int array for test puposes//
            examples[i] = i;
        }

        return examples;
    }

    private static Comparable[] generatePartialExample(int n) {
        Comparable[] examples = new Comparable[n];
        Random r = new Random();
        int high = n/2;
        int low = n/8;

        for(int i = 0; i < n; i++) {
            //Make an int array for test puposes//
            examples[i] = i;
        }

        for(int i = low; i < high; i++) {
            examples[i] = examples[r.nextInt(high-low) + low];
        }

        return examples;
    }

    private static void insertionSort(Comparable[] a, int low, int high) 
    {
        for(int i = low + 1; i < high + 1;i++) {

            for(int j = i; j > low; j--) {

                if(less(a[j], a[j-1])) {

                    exchange(a,j,j-1);
                }
                else break;
            }
        }
    }


    public static void main(String[] args)
    {
        /*int arraySize = 100000;
        String arrayType = "partial";
        double SortingTime = calculateTime(arraySize, arrayType);

        //System.out.println("time: " + SortingTime + " ms" + "\nSize: " + arraySize + " elements" +
        // "\nCutOff: 15");

        System.out.println("time: " + SortingTime + " ms");*/

        //Comparable[] array = {10, 120, 32, 2, 27, 342, 3, 11, 40, 22, 25, 30};

        //System.out.println(quickSelect(array, 0));
        

        //---------------------------- [ Median Sort Cutoff Summary ] ----------------------------//
        
        //Testing different cutOff values with random arrays of 100000 elements with 75 trials//
        //Every cutOff was tested 5 times, the time displayed is the average of them//

        //====================================//
        //---- [Median Sort CutOff Values] ----//
        //====================================//
        //     CutOff     ||     Time(ms)     //
        //        2               13.35       //    14.51   13.00   12.96   12.65   13.63
        //        4               12.89       //    13.14   12.42   12.73   12.68   13.47
        //        5               13.24       //    13.84   13.08   13.77   13.05   12.46
        //        8               13.05       //    12.93   13.97   12.53   13.32   12.48
        //       10               12.83       //    12.68   12.85   13.68   12.87   12.07
        //       12               12.79       //    12.57   11.91   12.72   12.16   14.60
        //       15               12.43       //    12.32   12.31   12.17   12.56   12.77
        //       20               12.53       //    12.42   12.81   12.42   12.57   12.45
        //       30               13.67       //    13.99   14.36   14.17   12.83   13.02
        //       40               14.57       //    15.01   13.88   14.06   14.97   14.92
        //      100               18.93       //    18.93   18.52   18.72   19.21   19.29
        //====================================//

        //We can conclude that one of the best values we've obtained was for the cutoff
        //value of 15, not only was one of the most stables time values we obtained but it
        //was the fastest!

        //-----------------------------[ Sort vs Median Sort Summary ]-----------------------------//

        //Once again we tested with arrays of 100000 elements 75 times!
        //I made tests for 4 type of arrays:
        //Arrays already sorted, inversed arrays, arrays with random numbers and arrays partially sorted
        //The result is time in ms

        //=================================================//
        //------------- [Sort vs Median Sort] -------------//
        //=================================================//
        //                  ||          ||                 //
        //                  ||   Sort   ||   Median Sort   //
        //                  ||          ||                 // 
        //------------------||----------||-----------------//
        //                  ||          ||                 //
        //   Sorted Array   ||  5.587   ||      1.453      //
        //                  ||          ||                 //
        //------------------||----------||-----------------//
        //                  ||          ||                 //
        //  Inversed Array  ||  6.307   ||      3.827      //
        //                  ||          ||                 //
        //------------------||----------||-----------------//
        //                  ||          ||                 //
        //   Random Array   ||  16.05   ||      12.21      //
        //                  ||          ||                 //
        //------------------||----------||-----------------//
        //                  ||          ||                 //
        //   Partial Array  ||  7.120   ||      5.213      //
        //                  ||          ||                 //
        //==================||==========||=================//

        //With these tests we can conclude that indeed the median Sort method is better than than
        //The normal quick sort sorting method in EVERY aspect!


        //--------------------------------[ Quick Select Tests ]--------------------------------//

        //The tests were made with arrays of 100 000 elements with 75 trials!
        //And only using random arrays!
        int n = 125;
        String arrayType = "random";
        double previousTime = calculateTime(n, arrayType);
        double newTime;
        double doublingRatio;

        for(int i = 250; true; i *= 2) {

            newTime = calculateTime(i, arrayType);
            if(previousTime > 0) {

                doublingRatio = newTime/previousTime;
            }
            else doublingRatio = 0;

            previousTime = newTime;
            System.out.println(i + "\t" + newTime + "\t" + doublingRatio);
        }

        // With this cade we got the following results \\
        //250     0.06666666666666667     5.0
        //500     0.08                    1.2
        //1000    0.09333333333333334     1.1666666666666667
        //2000    0.14666666666666667     1.5714285714285714
        //4000    0.36                    2.4545454545454546
        //8000    0.84                    2.3333333333333335
        //16000   1.7333333333333334      2.0634920634920637
        //32000   3.933333333333333       2.269230769230769
        //64000   9.053333333333333       2.301694915254237
        //128000  18.826666666666668      2.0795287187039766
        //256000  38.28                   2.03328611898017
        //512000  88.28                   2.3061650992685476

        //And we can see that the doublingRatio stabelized in arround the value of 2
        //Therefore "r" is approximately 2 wich means that the exponent "b" is equal to 1
        //In that case the error is O(n)!


    }
}   
