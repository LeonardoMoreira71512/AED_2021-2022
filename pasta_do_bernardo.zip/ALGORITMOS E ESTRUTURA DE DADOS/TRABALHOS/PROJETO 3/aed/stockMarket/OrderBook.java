package aed.stockMarket;

import aed.collections.MinPriorityQueue;
import aed.stockMarket.OrderBook.OrderType;

import java.time.LocalDateTime;

public class OrderBook {

    public enum OrderType {
        LIMIT,
        MARKET
    }

    public enum ActionType {
        BID,
        ASK
    }

    private static final float ticksPerUnit = 100.0f;
    private static long orderIDCounter = 0;

    private int lastBid;
    private int lastAsk;
    private int lastPrice;
    private int lastQuantity;
    private int minPrice;
    private int maxPrice;
    private int previousDayPrice;
    private int variation;
    private int processedOrders;
    private int unprocessedOrders;

    private int earnings;
    private int volume;
    private String stockTitle;

    private MinPriorityQueue<Order> asks;
    private MinPriorityQueue<Order> bids;


    public OrderBook(String stockTitle, int lastBid, int lastAsk)
    {
        this.stockTitle = stockTitle;
        this.lastBid = lastBid;
        this.lastAsk = lastAsk;
        this.lastPrice = lastBid;
        this.previousDayPrice = lastBid;
        this.maxPrice = Integer.MIN_VALUE;
        this.minPrice = Integer.MAX_VALUE;
        this.processedOrders = 0;
        this.unprocessedOrders = 0;
        this.earnings = 0;
        asks = new MinPriorityQueue<Order>();
        bids = new MinPriorityQueue<Order>();
    }

    public String getStockTitle()
    {
        return stockTitle;
    }

    public int getLastBid()
    {
        return lastBid;
    }

    public int getLastAsk()
    {
        return lastAsk;
    }

    public int getLastPrice()
    {
        return lastPrice;
    }

    public int getMinPrice()
    {
        return minPrice;
    }

    public int getMaxPrice()
    {
        return maxPrice;
    }

    public int getNextBestBid()
    {
        if(bids.isEmpty())
            return 0;

        if(bids.peekMin().orderType == OrderType.MARKET)
            return lastBid;

        return bids.peekMin().price;
    }

    public int getNextBestAsk()
    {
        if(asks.isEmpty())
            return 0;

        if(asks.peekMin().orderType == OrderType.MARKET)
            return lastAsk;
            
        return asks.peekMin().price;
    }

    public int getProcessedOrders()
    {
        return processedOrders;
    }

    public int getUnprocessedOrders()
    {
        return unprocessedOrders;
    }

    public int getVariation()
    {
        return variation;
    }

    public int getVolume()
    {
        return volume;
    }

    public int getBrokerEarnings()
    {
        return earnings;
    }

    public void placeMarketOrder(ActionType action, int quantity)
    {
        Order order =
        new Order(this.stockTitle,++orderIDCounter,action, OrderType.MARKET, quantity, 0);
        
        insertInQueue(action, order);
    }

    public void placeLimitOrder(ActionType action, int quantity, int price)
    {
        Order order = 
        new Order(this.stockTitle,++orderIDCounter,action, OrderType.LIMIT, quantity, price);
        
        insertInQueue(action, order);

    }

    private void insertInQueue(ActionType action, Order order) {

        unprocessedOrders++;

        if(action == ActionType.ASK)
            asks.insert(order);
        else
            bids.insert(order);
    }

    public int processNextOrder(boolean verbose)
    {
        // 1.
        if(asks.isEmpty() || bids.isEmpty())
            return 0;

        int result = 0;
        OrderType asksOrder = asks.peekMin().orderType;
        OrderType bidsOrder = bids.peekMin().orderType;

        if(asksOrder == OrderType.MARKET && bidsOrder == OrderType.MARKET)
            result = processMarketOrder();
        else if(asksOrder == OrderType.LIMIT && bidsOrder == OrderType.LIMIT)
            result = processLimitOrder();
        else if(asksOrder == OrderType.MARKET && bidsOrder == OrderType.LIMIT)
            result = processMarketAskLimitBid();
        else
            result = processLimitAskMarketBid();

        if(result == 0)
            return result;

        if(verbose)
            printOrderDetails();

        return result;
        
    }

    private void printOrderDetails() {

        float finalVariation = (float) variation/100;

        if(finalVariation >= 0)
            System.out.println(stockTitle + " - quantity: " + lastQuantity + 
            " price: " + lastPrice/ticksPerUnit + " +" + finalVariation + "%");
        else
            System.out.println(stockTitle + " - quantity: " + lastQuantity + 
            " price: " + lastPrice/ticksPerUnit + " " + finalVariation + "%");
    }

    private int processLimitOrder() {

        int askPrice = asks.peekMin().price;
        int bidPrice = bids.peekMin().price;

        // 2.
        if(askPrice > bidPrice)
            return 0;

        //3.
        return pair(askPrice, bidPrice);
    }

    private int processMarketOrder() {

        int askPrice = lastAsk;
        int bidPrice = lastBid;

        return pair(askPrice, bidPrice);       
    }


    private int processMarketAskLimitBid() {

        int bidPrice = bids.peekMin().price;
        int askPrice = Math.min(lastAsk, bidPrice);

        return pair(askPrice, bidPrice);
    }

    private int processLimitAskMarketBid() {

        int askPrice = asks.peekMin().price;
        int bidPrice = Math.max(lastBid, askPrice);

        return pair(askPrice, bidPrice);
    }

    private int pair(int askPrice, int bidPrice) {
        //3.
        int result;
        int askQuantity = asks.peekMin().quantity;
        int bidQuantity = bids.peekMin().quantity;

        // (b)
        int spread = bidPrice - askPrice;

        // (c)
        this.lastBid = bidPrice;
        this.lastAsk = askPrice;
        this.lastPrice = lastBid;

        if(lastPrice < minPrice)
            this.minPrice = lastPrice;
        if(lastPrice > maxPrice)
            this.maxPrice = lastPrice;

        this.variation = lastPrice - previousDayPrice;
        float finalVariation = variation/(float) previousDayPrice;
        this.variation = (int) (finalVariation * 10000);

        // (d)
        // (e)
        if(bidQuantity == askQuantity) {

            asks.removeMin();
            bids.removeMin();
            this.volume += bidQuantity;
            this.lastQuantity = bidQuantity;
            this.processedOrders += 2;
            this.unprocessedOrders -= 2;
            result = 2;
        }

        // (f)
        else if(bidQuantity < askQuantity) {

            asks.peekMin().quantity -= bidQuantity;
            bids.removeMin();
            this.volume += bidQuantity;
            this.lastQuantity = bidQuantity;
            this.processedOrders++;
            this.unprocessedOrders--;
            result = 1;
        }

        // (g)
        else {

            bids.peekMin().quantity -= askQuantity;
            asks.removeMin();
            this.volume += askQuantity;
            this.lastQuantity = askQuantity;
            this.processedOrders++;
            this.unprocessedOrders--;
            result = 1;
        }
        // (h)

        this.earnings += spread * lastQuantity;

        return result;
    }

    public boolean processNextOrders(int n, boolean verbose)
    {
        int result = 0;
        int testOrders = 0;

        while(result < n) {

            testOrders = processNextOrder(verbose);
            
            if(testOrders == 0)
                return false;
        
            result += testOrders;
        }

        return true;
    }

    public void printSummary()
    {
        System.out.println("Daily transaction summary for stock: " + this.getStockTitle());
        System.out.println("Orders processed: " + getProcessedOrders());
        System.out.println("Transaction volume: " + getVolume());
        System.out.println("Last Price: " + getLastBid()/ticksPerUnit + (getVariation() < 0 ? " " : " +") + getVariation()/ticksPerUnit + "%");
        System.out.println("Maximum Price: " + this.maxPrice/ticksPerUnit);
        System.out.println("Minimum Price: " + this.minPrice/ticksPerUnit);
        System.out.println("Orders not processed: " + getUnprocessedOrders());
        System.out.println("Best remaining ask: " + getNextBestAsk()/ticksPerUnit);
        System.out.println("Best remaining bid: " + getNextBestBid()/ticksPerUnit);
        System.out.println("Daily earnings: " + getBrokerEarnings()/ticksPerUnit);
    }
}

class Order implements Comparable<Order> {


    private static final float ticksPerUnit = 100.0f;

    @Override
    public int compareTo(Order o) {

        int result = 0;

        //Check if they're both Market or Limit orders
        //If don't continue
        if(this.orderType == OrderType.MARKET && o.orderType == OrderType.LIMIT) {
            return -1;
        } else if(this.orderType == OrderType.LIMIT && o.orderType == OrderType.MARKET) {
            return 1;
        }

        switch(orderType) {
            
            case MARKET:
                result = (int) (this.orderID - o.orderID);
            break;

            case LIMIT:
                result = limitPriority(o);
            break;
        }

		return result;
    }

    private int limitPriority(Order o) {

        int result = 0;

        switch(action) {
            case ASK:
                result = this.price - o.price;
            break;

            case BID:
                result = o.price - this.price;
            break;
        }

        if(result == 0)
            result = (int) (this.orderID - o.orderID);

        return result;  
    }

    final LocalDateTime time;
    final long orderID;
    int quantity;
    final OrderBook.OrderType orderType;
    final int price;
    final OrderBook.ActionType action;
    final String stockTitle;

    public Order(String stockTitle, long orderID, OrderBook.ActionType action, OrderBook.OrderType order, int quantity, int price)
    {
        this.stockTitle = stockTitle;
        this.orderID = orderID;
        this.action = action;
        this.orderType = order;
        this.time = LocalDateTime.now();
        this.quantity = quantity;
        this.price = price;
    }

    public String toString()
    {
        String result = this.action.toString() + " ID: " + this.orderID  + " type: " + this.orderType.toString() + " quantity: " + this.quantity;
        if(this.orderType == OrderBook.OrderType.LIMIT) result += " price: " + this.price/ticksPerUnit;

        return result;
    }

}
