package aed;

import aed.stockMarket.OrderBook;
import aed.stockMarket.OrderBook.ActionType;

public class Main {
    
    public static void main(String[] args) {

        OrderBook Tesla = new OrderBook("Tesla", 327, 200);

        Tesla.placeMarketOrder(ActionType.BID, 25);
        Tesla.placeMarketOrder(ActionType.BID, 10);
        Tesla.placeMarketOrder(ActionType.BID, 40);
        Tesla.placeLimitOrder(ActionType.ASK, 20, 325);
        Tesla.placeLimitOrder(ActionType.ASK, 15, 327);
        Tesla.placeLimitOrder(ActionType.ASK, 25, 329);

        //Tesla.printSummary();

        System.out.println(Tesla.processNextOrders(6, true));

        //Tesla.printSummary();
    }
    
}
