package aed.collections;

import java.util.Random;

import aed.sorting.Sort;

public class MinPriorityQueue<T extends Comparable<T>> extends Sort {
    //minimum size that an array for the PriorityQueue should have
    private static final int MIN_MAXSIZE = 64;

    private T[] elements;
    private int maxSize;
    private int size;
	
	public MinPriorityQueue<T> clone()
    {
        MinPriorityQueue<T> result = new MinPriorityQueue<T>(this.maxSize);
        result.size = this.size;
        result.elements = this.elements.clone();

       return result;
    }
   
    @SuppressWarnings("unchecked")
    public MinPriorityQueue()
    {
        size = 0;
        maxSize = MIN_MAXSIZE;
        elements = (T[]) new Comparable[MIN_MAXSIZE + 1];
    }

    @SuppressWarnings("unchecked")
    public MinPriorityQueue(int initialMaxSize)
    {
        size = 0;

        if(initialMaxSize > MIN_MAXSIZE) {
            maxSize = initialMaxSize;
            elements = (T[]) new Comparable[maxSize + 1];
        }
        else{
            maxSize = MIN_MAXSIZE;
            elements = (T[]) new Comparable[maxSize + 1];
        }
    }

    @SuppressWarnings("unchecked")
    public MinPriorityQueue(T[] a)
    {
        if(a.length * 2 >= MIN_MAXSIZE) {
            maxSize = a.length * 2;
            elements = (T[]) new Comparable[maxSize + 1];
        }
        else {
            maxSize = MIN_MAXSIZE;
            elements = (T[]) new Comparable[maxSize + 1];
        }

        //Adicionar a raiz
        elements[1] = a[0];
        size++;

        //Inserir os elementos do array
        for(int i = 1; i < a.length;i++) {
            insert(a[i]);
        }

        
    }

    //needed for testing purposes only
    public Comparable[] getElements()
    {
        return elements;
    }

    public static <T extends Comparable<T>> boolean isMinHeap(T[] a, int n)
    {   
        return isMinHeap(a, 1, n);
    }

    private static <T extends Comparable<T>> boolean isMinHeap(T[] a, int father, int n) {

        int child = father * 2;

        //Verify if the father is in the n element
        //If it is, we already finished all the checks and it is a minHeap
        //If it's not the last element, we will check if the childs are not less than the father
        //if they aren't we'll return false
        if(child >= n)
            return true;
        else if(a[father].compareTo(a[child]) > 0 || a[father].compareTo(a[child + 1]) > 0)
            return false;
        

        //If they are we will check if the childs of the childs are lower
        if(isMinHeap(a, child, n) && isMinHeap(a, child + 1, n))
            return true;

        return false;

    }

    public void insert(T t)
    {
        //Insert element in the end of the array
        elements[size + 1] = t;

        //Increase Size
        size++;

        //Check if we passed the maximum ammount of the array
        if(size >= maxSize)
            elements = resizeArray();

        //Create a temp variable to store the new size
        int k = size;

        //Heapify (swim up)
        while(k > 1 && less(elements[k], elements[k/2])) {

            exchange(elements, k, k/2);
            k = k/2;
        }
    }

    @SuppressWarnings("unchecked")
    private T[] resizeArray() {

        maxSize *= 2;
        T[] newElements = (T[]) new Comparable[maxSize + 1];

        for(int i = 0; i < size + 1; i++) {
            newElements[i] = elements[i];
        }

        return newElements;
    }

    public T peekMin()
    {
        return elements[1];
    }

    public T removeMin()
    {
        //Verifiy if it's empty
        if(isEmpty())
            return null;

        //Put the root in avariable
        //Remove the current root, by choosing another one (the last element)
        T root = elements[1];
        elements[1] = elements[size];
        elements[size] = null;
        
        //Decrease Size
        size--;

        if(size <= maxSize/4)
            elements = reduceArray();

        //Heapify ( Sink )

        int k = 1;
        int child = k*2;

        while(child <= size) {
            
            //choose the lower child between the two
            if(child < size && less(elements[child + 1], elements[child]))
                child++;

            //If the father is already less than the child
            //We stop here
            if(less(elements[k], elements[child]))
                break;
            exchange(elements, k, child);
            k = child; //We will now make the child father, and test the further childs
            child = 2*k; //And the childs will now be, the childs of the previous child!
        }

		return root;
    }

    @SuppressWarnings("unchecked")
    private T[] reduceArray() {

        if(maxSize/2 >= MIN_MAXSIZE) 
            maxSize /= 2;
        else
            maxSize = MIN_MAXSIZE;

        T[] newElements = (T[]) new Comparable[maxSize + 1];

        for(int i = 0; i < size + 1; i++) {
            newElements[i] = elements[i];
        }

        return newElements;

    }

    public boolean isEmpty()
    {
        return elements[1] == null;
    }

    public int size()
    {
        return size;
    }

    //needed for testing purposes
    public int getMaxSize()
    {
        return maxSize;
    }
    
    @SuppressWarnings("unchecked")
	public static void main(String[] args)
    {
        Integer[] testArray = new Integer[50];
        Random r = new Random();

        for(int i = 0; i < testArray.length; i++) {
            testArray[i] = r.nextInt(1000);
        }

        MinPriorityQueue<Integer> queueTest = new MinPriorityQueue<Integer>(testArray);

        Comparable[] queueArray = queueTest.getElements();

        for (Comparable el : queueArray) {
            System.out.println(el);
        }

        System.out.println("\n");
        System.out.println("Size: " + queueTest.size());
        System.out.println("maxSize: " + queueTest.getMaxSize());
        System.out.println("Number of elements in queue: " + queueArray.length);
        System.out.println("Is Min Heap? " + isMinHeap(queueArray, queueTest.size()));
        queueArray[queueTest.size() - 1] = -200;
        isMinHeap(queueArray, queueTest.size());
        System.out.println("Is Min Heap? " + isMinHeap(queueArray, queueTest.size()));
        
    }
}
