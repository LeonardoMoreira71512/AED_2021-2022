package aed.collections;

import java.util.Iterator;

import java.util.Arrays;

public class ULLQueue<T> implements IQueue<T> {

	@SuppressWarnings("hiding")
	private class Node<T> {
		private T[] item;
		private int numElements;
		private int indexToRemove;
		@SuppressWarnings("rawtypes")
		private Node next;

		@SuppressWarnings("unchecked")
		public Node() {
			this.item = (T[]) new Object[blockSize];
			numElements = 0;
			indexToRemove = 0;
			next = null;
		}
	}

	private Node<T> head;
	private Node<T> tail;
	private int size;
	private int blockSize;

	public ULLQueue() {
		this.head = null;
		this.tail = null;
		this.size = 0;
		this.blockSize = 64;
	}

	public ULLQueue(int blockSize) {
		this.head = null;
		this.tail = null;
		this.size = 0;
		this.blockSize = blockSize;
	}

	@Override
	public Iterator<T> iterator() {
		return null;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void enqueue(T item) {
		if (this.head == null) {
			this.head = new Node();
			this.tail = this.head;
			size++;
		}
		Node current = this.tail;
		if (current.numElements < blockSize) {
			current.item[current.numElements] = item;
			current.numElements++;
		} else {
			current.next = new Node();
			current = current.next;
			this.tail = current;
			current.item[current.numElements] = item;
			current.numElements++;
			size++;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public T dequeue() {
		@SuppressWarnings("rawtypes")
		Node current = this.head;
		T elementToRemove = null;
		if (current != null) {

			elementToRemove = (T) current.item[current.indexToRemove];
			current.numElements--;
			current.item[current.indexToRemove] = null;
			current.indexToRemove++;

			if (current.numElements <= 0 && size > 0) {
				this.head = this.head.next;
				this.size--;
			}
			return elementToRemove;
		} else
			return null;

	}

	@SuppressWarnings({ "null" })
	@Override
	public T peek() {
		if (head != null)
			return head.item[head.indexToRemove];
		else
			return null;
	}

	@Override
	public boolean isEmpty() {
		return size < 1;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public int size() {
		Node current = this.head;
		int size = 0;
		while (current != null) {
			size += current.numElements;
			current = current.next;
		}
		return size;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public IQueue<T> shallowCopy() {
		Node current = this.head;
		ULLQueue<T> newqueue = new ULLQueue<T>(blockSize);
		newqueue.head = new Node();
		Node newCurrent = newqueue.head;
		while (current != null) {
			for (int i = 0; i < current.numElements; i++) {
				newCurrent.item[i] = current.item[i];
				newCurrent.numElements++;
			}
			if (current.next != null)
				newCurrent.next = new Node();
			current = current.next;
			newCurrent = newCurrent.next;
		}
		newqueue.size = this.size();
		return newqueue;
	}

	@SuppressWarnings({ "unchecked", "rawtypes", "unused" })
	public T[][] getArrayOfBlocks() {
		T[][] array;
		array = (T[][]) new Object[size][blockSize];
		Node current = this.head;
		int cnt = 0;
		while (current != null) {
			for (int i = 0; i < blockSize; i++) {
				array[cnt][i] = (T) current.item[i];
			}
			if (current.numElements == blockSize) {
				Node currentnext = current.next;
				currentnext = new Node();
			}
			current = current.next;
			cnt++;
		}
		return array;
	}

	public static void main(String[] args) {
		ULLQueue<String> queue = new ULLQueue<String>(30);

		queue.enqueue("I'm");
		queue.enqueue("good");
		queue.enqueue("at");
		queue.enqueue("everything");
		queue.enqueue("except");
		queue.enqueue("the");
		queue.enqueue("things");
		queue.enqueue("I");
		queue.enqueue("can't");
		queue.enqueue("do");

		System.out.println("----------LIST AFTER ENQUEUE(T item) METHOD----------");
		System.out.println(Arrays.deepToString(queue.getArrayOfBlocks()));

		System.out.println();

		System.out.println("----------LIST AFTER PEEK() METHOD");
		queue.peek();
		System.out.println(Arrays.deepToString(queue.getArrayOfBlocks()));

		System.out.println();

		System.out.println("----------LIST AFTER DEQUEUE() METHOD----------");
		queue.dequeue();
		System.out.println(Arrays.deepToString(queue.getArrayOfBlocks()));

		System.out.println();

		System.out.println("----------LIST AFTER PEEK() METHOD");
		queue.peek();
		System.out.println(Arrays.deepToString(queue.getArrayOfBlocks()));

		System.out.println("----------SIZE OF THE LIST: " + queue.size() + " ----------");

		System.out.println();

		System.out.println("----------LIST AFTER SHALLOW COPY()----------");
		ULLQueue<String> shallowCopy = (ULLQueue<String>) queue.shallowCopy();
		System.out.println(Arrays.deepToString(shallowCopy.getArrayOfBlocks()));

		System.out.println();

		System.out.println("----------Is the list empty?: " + queue.isEmpty());
		
	}
}
