package aed.collections;

import java.util.*;
import java.util.Stack;


public class incognito {

	
	public static int [] somaNPares(int n, int[] a) {
		int []b;
		for(int i = 0; i<a.length; i++) {
		if(a[i] < n)
		b = a[i];
		}
		return b;
	}
	 
    /*static Stack<Integer> s = new Stack<Integer>();
    
	public static int incognito(int n) {
		int res = 0;
		for (int k = 0; k < n; k++) {
			for (int j = n; j > 0; j--) {
				res++;
			}
		}
		return res;
	}
	
	public static void test_stack() {
		
		int j;
		s.push(0);
		for (int i = 1; i < 5; i++) {
			j = s.pop();
			s.push(i);
			s.push(j);
			s.push(i);
		}

		while (s.size() > 0) {
			System.out.print(s.pop() + ",");
		}
	}*/
	
	/*public static int xpto2(int []num, int n) {
		int sum = 0;
		for(int i = 0; i < num.length; i++) {
			if(num[i]%n == 0)
				sum += num[i];
		}
		return sum;
	}*/
	
	


	public static void main(String[] args) {
		
		/*int x = incognito(0);
		int y = incognito(2);
		int z = incognito(4);
		
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		
		test_stack();*/
		
		/*int[] num = { 2, 4, 6, 3, 5, 9 };
		int result = xpto2(num, 3);
		System.out.println(result);*/

		System.out.println("-----------------------");
		
		int []a = {8,6,5,4,3,2,1};
		int n = 3;
		System.out.println(somaNPares(n, a));
		
		/*final Stack<Integer> s = new Stack<Integer>();
		int j;
		s.push(0);
		for (int i = 1; i < 5; i++) {
			j = s.pop();
			s.push(i);
			s.push(j);
			s.push(i);
		}

		while (s.size() > 0) {
			System.out.print(s.pop() + ",");
		}*/
	
	}

}
