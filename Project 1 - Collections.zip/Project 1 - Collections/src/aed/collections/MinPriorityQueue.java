package aed.collections;

import java.util.Arrays;
import java.util.Random;

public class MinPriorityQueue<T extends Comparable<T>> {

	UnrolledLinkedList<T> ull;

	public static void main(String[] args) {

		int n = 31;
		var array = new Integer[31];

		for (int i = 0; i < n;i++) 
			array[i] = i;

		shuffle(array);
		System.out.println("unordered");
		System.out.println(Arrays.toString(array));

		var minQueue = new MinPriorityQueue<Integer>();

		for (Integer i : array)
			minQueue.insert(i);

		System.out.println("ordered");
		System.out.println(Arrays.toString(minQueue.getElements()));
		
		 var minQueueCopy = minQueue.shallowCopy();

	        for(int i = 0; i < n; i++) {	
	        	minQueue.removeMin();
	        	minQueue.removeMin();
	        }

	        System.out.println("original");
	        System.out.println(Arrays.toString(minQueue.getElements()));
	        System.out.println("copy");
	        System.out.println(Arrays.toString(minQueueCopy.getElements()));

	        for(Integer i : array)
	        	minQueue.insert(i);
	        
	        System.out.println("original after inserting again");
	        System.out.println(Arrays.toString(minQueue.getElements()));
	}

	public MinPriorityQueue() {
		ull = new UnrolledLinkedList<>(2928);
	}

	public MinPriorityQueue(int blockSize) {
		ull = new UnrolledLinkedList<>(blockSize);
	}

	public MinPriorityQueue<T> shallowCopy() {

		MinPriorityQueue<T> copy = new MinPriorityQueue<>();

		for (T t : ull) {
			copy.insert(t);
		}
		return copy;
	}

	public T[] getElements() {
		@SuppressWarnings("unchecked")
		T[] a = (T[]) new Comparable[size()];
		int i = size() - 1;
		for (T element : ull)
			a[i--] = element;
		return a;
	}

	public void insert(T element) {
		ull.addAt(reverseBinarySearch(element), element);
	}

	public T peekMin() {
		if (ull.isEmpty())
			return null;
		return ull.get(size() - 1);
	}

	public T removeMin() {
		return ull.remove();
	}

	public boolean isEmpty() {
		return ull.isEmpty();
	}

	public int size() {
		return ull.size();
	}

	private int reverseBinarySearch(T key) {
		int lo = 0, hi = size() - 1;
		while (hi - lo > 1) {
			int mid = lo + (hi - lo) / 2;
			var midKey = ull.get(mid);
			if (less(key, midKey))
				lo = mid;
			else if (less(midKey, key))
				hi = mid;
			else
				return mid;
		}
		if (hi >= 0 && less(key, ull.get(hi)))
			return hi + 1;
		if (hi > 0 && less(key, ull.get(lo)))
			return lo + 1;
		return lo;
	}

	private static <T extends Comparable<T>> boolean less(T v, T w) {
		return v.compareTo(w) < 0;
	}

	private static <T extends Comparable<T>> void shuffle(T[] a) {
		Random r = new Random();

		for (int i = a.length - 1; i > 0; i--) {
			int j = r.nextInt(i + 1);
			exchange(a, i, j);
		}
	}

	protected static <T extends Comparable<T>> void exchange(T[] a, int i, int j) {
		T t = a[i];
		a[i] = a[j];
		a[j] = t;
	}

	public static <T extends Comparable<T>> boolean isSorted(T[] a) {
		for (int i = 1; i < a.length; i++) {
			if (less(a[i], a[i - 1]))
				return false;
		}
		return true;
	}

}
